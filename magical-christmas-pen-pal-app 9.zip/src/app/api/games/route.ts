import { NextResponse } from "next/server";
import { db } from "@/db";
import { achievements, notifications } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { getCurrentChild } from "@/lib/auth";
import { GAME_CATALOG } from "@/lib/elf-data";

export async function POST(request: Request) {
  const current = await getCurrentChild();
  if (!current) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const { gameKey, score } = (await request.json()) as { gameKey: string; score: number };
  const game = GAME_CATALOG.find((g) => g.key === gameKey);
  if (!game) return NextResponse.json({ error: "Unknown game" }, { status: 400 });

  const existing = await db
    .select()
    .from(achievements)
    .where(and(eq(achievements.childId, current.child.id), eq(achievements.gameKey, gameKey)))
    .limit(1);

  let isNew = false;
  if (existing[0]) {
    if (score > existing[0].score) {
      await db.update(achievements).set({ score }).where(eq(achievements.id, existing[0].id));
    }
  } else {
    isNew = true;
    await db.insert(achievements).values({
      childId: current.child.id,
      gameKey,
      badge: game.badge,
      score,
    });
    if (current.child.parentId) {
      await db.insert(notifications).values({
        parentId: current.child.parentId,
        childId: current.child.id,
        type: "achievement",
        title: `New badge earned! 🏆`,
        body: `${current.child.firstName} earned the "${game.badge}" badge in ${game.title}.`,
      });
    }
  }

  return NextResponse.json({ ok: true, badge: game.badge, isNew });
}
