import { NextResponse } from "next/server";
import { db } from "@/db";
import { children, elves, letters, notifications, memories } from "@/db/schema";
import { eq } from "drizzle-orm";
import { createSession, makeMagicCode, getSession } from "@/lib/auth";
import { ensureElvesSeeded } from "@/lib/seed";
import { syncUnlocks } from "@/lib/progress";

export async function POST(request: Request) {
  await ensureElvesSeeded();
  const body = (await request.json()) as {
    mode: "register" | "login";
    firstName?: string;
    age?: number;
    favoriteColor?: string;
    favoriteActivity?: string;
    christmasWish?: string;
    birthday?: string;
    elfId?: number;
    magicCode?: string;
  };

  if (body.mode === "login") {
    const code = (body.magicCode ?? "").trim().toUpperCase();
    if (!code) return NextResponse.json({ error: "Please type your magic code." }, { status: 400 });
    const rows = await db.select().from(children).where(eq(children.magicCode, code)).limit(1);
    const kid = rows[0];
    if (!kid) return NextResponse.json({ error: "Hmm, that magic code isn't in Santa's book." }, { status: 401 });
    await createSession({ role: "child", childId: kid.id });
    return NextResponse.json({ ok: true, magicCode: kid.magicCode });
  }

  const firstName = (body.firstName ?? "").trim();
  const age = Number(body.age ?? 0);
  const favoriteColor = (body.favoriteColor ?? "").trim();
  const favoriteActivity = (body.favoriteActivity ?? "").trim();
  const elfId = Number(body.elfId ?? 0);

  if (!firstName || !age || !favoriteColor || !favoriteActivity || !elfId) {
    return NextResponse.json({ error: "Please fill in every magical box." }, { status: 400 });
  }

  const elfRows = await db.select().from(elves).where(eq(elves.id, elfId)).limit(1);
  const elf = elfRows[0];
  if (!elf) return NextResponse.json({ error: "That elf couldn't be found." }, { status: 400 });

  // link to signed-in parent, if any
  const session = await getSession();
  const parentId = session?.role === "parent" ? session.parentId ?? null : null;

  let magicCode = makeMagicCode(firstName);
  for (let i = 0; i < 5; i++) {
    const clash = await db.select().from(children).where(eq(children.magicCode, magicCode)).limit(1);
    if (!clash[0]) break;
    magicCode = makeMagicCode(firstName);
  }

  const inserted = await db
    .insert(children)
    .values({
      parentId,
      firstName,
      age,
      favoriteColor,
      favoriteActivity,
      christmasWish: body.christmasWish?.trim() || null,
      birthday: body.birthday?.trim() || null,
      elfId,
      magicCode,
      lettersSent: 0,
    })
    .returning();
  const kid = inserted[0];

  await db.insert(memories).values([
    { childId: kid.id, kind: "fact", value: `favourite colour: ${favoriteColor}` },
    { childId: kid.id, kind: "fact", value: `loves ${favoriteActivity}` },
    ...(body.christmasWish ? [{ childId: kid.id, kind: "wish", value: `Christmas wish: ${body.christmasWish}` }] : []),
    ...(body.birthday ? [{ childId: kid.id, kind: "date", value: `birthday: ${body.birthday}` }] : []),
  ]);

  // Welcome letter from the chosen elf
  await db.insert(letters).values({
    childId: kid.id,
    elfId: elf.id,
    sender: "elf",
    body: `Dear ${firstName},

IT'S OFFICIAL! Ivy just stamped the friendship scroll in the Great Letter Hall and your name is now written next to mine in shimmering ink. I am your elf pen pal and I could not be more excited.

Let me introduce myself properly. I'm ${elf.name}, and my job at the North Pole is ${elf.job.toLowerCase()}. When I'm not working you'll find me ${elf.hobbies.toLowerCase()}. My favourite treat is ${elf.treats.toLowerCase()} — I once ate so many that Santa had to hide the tin.

A little bird (alright, it was a penguin) told me your favourite colour is ${favoriteColor.toLowerCase()} and that you love ${favoriteActivity.toLowerCase()}. I painted a tiny ornament ${favoriteColor.toLowerCase()} this morning and hung it on the workshop tree just for you.

Now it's your turn! Write back and tell me anything at all — what you did today, your best joke, your biggest wish. I promise to remember every single word.

${elf.catchphrase}

Your friend,
${elf.name} ${elf.emoji}`,
  });

  await syncUnlocks(kid.id, 0);

  if (parentId) {
    await db.insert(notifications).values({
      parentId,
      childId: kid.id,
      type: "child",
      title: `${firstName} joined the North Pole! 🎄`,
      body: `${firstName} chose ${elf.name} as their elf pen pal. Magic code: ${magicCode}`,
    });
  }

  // Keep the parent signed in if they created the profile from the parent portal.
  if (!parentId) {
    await createSession({ role: "child", childId: kid.id });
  }
  return NextResponse.json({ ok: true, magicCode, elf: elf.name, fromParent: Boolean(parentId) });
}
