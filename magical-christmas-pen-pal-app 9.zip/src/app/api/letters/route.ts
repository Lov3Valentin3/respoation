import { NextResponse } from "next/server";
import { db } from "@/db";
import { letters, memories, children, notifications } from "@/db/schema";
import { eq, desc, and } from "drizzle-orm";
import { getCurrentChild, getSession } from "@/lib/auth";
import { extractMemories, generateElfReply } from "@/lib/elf-brain";
import { syncUnlocks } from "@/lib/progress";

export async function GET() {
  const current = await getCurrentChild();
  if (!current) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const rows = await db
    .select()
    .from(letters)
    .where(eq(letters.childId, current.child.id))
    .orderBy(desc(letters.createdAt));
  return NextResponse.json({ letters: rows });
}

export async function POST(request: Request) {
  const body = (await request.json()) as { body?: string; childId?: number; asParent?: boolean };
  const text = (body.body ?? "").trim();
  if (text.length < 2) return NextResponse.json({ error: "Please write a little more!" }, { status: 400 });

  // Parent writing a reply on behalf of the elf
  if (body.asParent) {
    const session = await getSession();
    if (!session || session.role !== "parent" || !session.parentId) {
      return NextResponse.json({ error: "Not signed in" }, { status: 401 });
    }
    const kidRows = await db
      .select()
      .from(children)
      .where(and(eq(children.id, Number(body.childId)), eq(children.parentId, session.parentId)))
      .limit(1);
    const kid = kidRows[0];
    if (!kid) return NextResponse.json({ error: "Child not found" }, { status: 404 });
    await db.insert(letters).values({
      childId: kid.id,
      elfId: kid.elfId,
      sender: "elf",
      body: text,
    });
    return NextResponse.json({ ok: true });
  }

  const current = await getCurrentChild();
  if (!current || !current.elf) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const { child, elf } = current;

  await db.insert(letters).values({ childId: child.id, elfId: elf.id, sender: "child", body: text });

  // Learn new memories
  const facts = extractMemories(text);
  if (facts.length) {
    await db.insert(memories).values(facts.map((f) => ({ childId: child.id, kind: f.kind, value: f.value })));
  }

  const lettersSent = child.lettersSent + 1;
  await db.update(children).set({ lettersSent }).where(eq(children.id, child.id));

  if (child.parentId) {
    await db.insert(notifications).values({
      parentId: child.parentId,
      childId: child.id,
      type: "letter",
      title: `${child.firstName} wrote to ${elf.name} 💌`,
      body: text.slice(0, 140),
    });
  }

  let reply: string | null = null;

  if (!child.paused && child.responseMode !== "parent") {
    const memoryRows = await db.select().from(memories).where(eq(memories.childId, child.id));
    reply = await generateElfReply({
      child,
      elf,
      letter: text,
      memories: memoryRows.map((m) => m.value).slice(-12),
      letterCount: lettersSent,
    });
    await db.insert(letters).values({ childId: child.id, elfId: elf.id, sender: "elf", body: reply });
    if (child.parentId) {
      await db.insert(notifications).values({
        parentId: child.parentId,
        childId: child.id,
        type: "letter",
        title: `${elf.name} replied to ${child.firstName} ✨`,
        body: reply.slice(0, 140),
      });
    }
  }

  const unlocks = await syncUnlocks(child.id, lettersSent);
  return NextResponse.json({ ok: true, reply, paused: child.paused, unlocks });
}

export async function PATCH(request: Request) {
  const current = await getCurrentChild();
  if (!current) return NextResponse.json({ error: "Not signed in" }, { status: 401 });
  const { id } = (await request.json()) as { id: number };
  await db
    .update(letters)
    .set({ read: true })
    .where(and(eq(letters.id, id), eq(letters.childId, current.child.id)));
  return NextResponse.json({ ok: true });
}

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
