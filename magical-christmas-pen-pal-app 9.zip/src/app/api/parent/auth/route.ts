import { NextResponse } from "next/server";
import { db } from "@/db";
import { parents, notifications } from "@/db/schema";
import { eq } from "drizzle-orm";
import { hashPassword, verifyPassword, createSession } from "@/lib/auth";
import { ensureElvesSeeded } from "@/lib/seed";

export async function POST(request: Request) {
  await ensureElvesSeeded();
  const body = (await request.json()) as {
    mode: "register" | "login";
    email?: string;
    password?: string;
    name?: string;
  };

  const email = (body.email ?? "").trim().toLowerCase();
  const password = body.password ?? "";

  if (!email || !password) {
    return NextResponse.json({ error: "Email and password are required." }, { status: 400 });
  }

  if (body.mode === "register") {
    const name = (body.name ?? "").trim();
    if (!name) return NextResponse.json({ error: "Please tell us your name." }, { status: 400 });
    if (password.length < 6)
      return NextResponse.json({ error: "Password must be at least 6 characters." }, { status: 400 });

    const existing = await db.select().from(parents).where(eq(parents.email, email)).limit(1);
    if (existing[0]) {
      return NextResponse.json({ error: "That email already has a North Pole account." }, { status: 409 });
    }

    const inserted = await db
      .insert(parents)
      .values({ email, name, passwordHash: hashPassword(password) })
      .returning();
    const parent = inserted[0];

    await db.insert(notifications).values({
      parentId: parent.id,
      type: "welcome",
      title: "Welcome to the North Pole!",
      body: "Your family account is ready. Add your first child to choose an elf pen pal.",
    });

    await createSession({ role: "parent", parentId: parent.id });
    return NextResponse.json({ ok: true, parent: { id: parent.id, name: parent.name } });
  }

  const rows = await db.select().from(parents).where(eq(parents.email, email)).limit(1);
  const parent = rows[0];
  if (!parent || !verifyPassword(password, parent.passwordHash)) {
    return NextResponse.json({ error: "That email or password isn't on the list." }, { status: 401 });
  }
  await createSession({ role: "parent", parentId: parent.id });
  return NextResponse.json({ ok: true, parent: { id: parent.id, name: parent.name } });
}
