import { NextResponse } from "next/server";
import { db } from "@/db";
import { children, notifications, subscriptions, parents, certificates } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { getCurrentParent } from "@/lib/auth";
import { PLANS, ADDONS, CERTIFICATE_CATALOG } from "@/lib/elf-data";

export async function POST(request: Request) {
  const parent = await getCurrentParent();
  if (!parent) return NextResponse.json({ error: "Not signed in" }, { status: 401 });

  const body = (await request.json()) as {
    action: string;
    childId?: number;
    responseMode?: string;
    paused?: boolean;
    plan?: string;
    addons?: string[];
    certificateKey?: string;
    notificationId?: number;
  };

  switch (body.action) {
    case "updateChild": {
      const kidRows = await db
        .select()
        .from(children)
        .where(and(eq(children.id, Number(body.childId)), eq(children.parentId, parent.id)))
        .limit(1);
      if (!kidRows[0]) return NextResponse.json({ error: "Child not found" }, { status: 404 });
      await db
        .update(children)
        .set({
          responseMode: body.responseMode ?? kidRows[0].responseMode,
          paused: body.paused ?? kidRows[0].paused,
        })
        .where(eq(children.id, kidRows[0].id));
      return NextResponse.json({ ok: true });
    }

    case "linkChild": {
      // attach an existing standalone child profile by magic code
      const code = String(body.certificateKey ?? "").toUpperCase();
      const kid = (await db.select().from(children).where(eq(children.magicCode, code)).limit(1))[0];
      if (!kid) return NextResponse.json({ error: "No child with that magic code." }, { status: 404 });
      if (kid.parentId && kid.parentId !== parent.id) {
        return NextResponse.json({ error: "That child is already linked to another parent." }, { status: 409 });
      }
      await db.update(children).set({ parentId: parent.id }).where(eq(children.id, kid.id));
      return NextResponse.json({ ok: true });
    }

    case "subscribe": {
      const plan = PLANS.find((p) => p.key === body.plan);
      if (!plan) return NextResponse.json({ error: "Unknown plan" }, { status: 400 });
      const addonKeys = (body.addons ?? []).filter((a) => ADDONS.some((x) => x.key === a));
      const addonTotal = addonKeys.reduce(
        (sum, key) => sum + (ADDONS.find((a) => a.key === key)?.priceCents ?? 0),
        0,
      );
      await db
        .update(subscriptions)
        .set({ status: "cancelled" })
        .where(and(eq(subscriptions.parentId, parent.id), eq(subscriptions.status, "active")));
      await db.insert(subscriptions).values({
        parentId: parent.id,
        plan: plan.key,
        addons: addonKeys,
        priceCents: plan.priceCents + addonTotal,
      });
      await db.update(parents).set({ plan: plan.key }).where(eq(parents.id, parent.id));
      await db.insert(notifications).values({
        parentId: parent.id,
        type: "billing",
        title: "Membership activated 🎉",
        body: `${plan.name} is now active${addonKeys.length ? ` with ${addonKeys.length} add-on(s)` : ""}. Unlimited elf letters unlocked!`,
      });
      return NextResponse.json({ ok: true });
    }

    case "unlockPremiumCertificate": {
      const cert = CERTIFICATE_CATALOG.find((c) => c.key === body.certificateKey);
      const kid = (
        await db
          .select()
          .from(children)
          .where(and(eq(children.id, Number(body.childId)), eq(children.parentId, parent.id)))
          .limit(1)
      )[0];
      if (!cert || !kid) return NextResponse.json({ error: "Not found" }, { status: 404 });
      const owned = await db
        .select()
        .from(certificates)
        .where(and(eq(certificates.childId, kid.id), eq(certificates.key, cert.key)))
        .limit(1);
      if (!owned[0]) {
        await db.insert(certificates).values({
          childId: kid.id,
          key: cert.key,
          title: cert.title,
          premium: cert.premium,
        });
        await db.insert(notifications).values({
          parentId: parent.id,
          childId: kid.id,
          type: "certificate",
          title: "Premium certificate purchased 🏅",
          body: `${cert.title} is now in ${kid.firstName}'s trophy case.`,
        });
      }
      return NextResponse.json({ ok: true });
    }

    case "readNotification": {
      await db
        .update(notifications)
        .set({ read: true })
        .where(and(eq(notifications.id, Number(body.notificationId)), eq(notifications.parentId, parent.id)));
      return NextResponse.json({ ok: true });
    }

    case "readAllNotifications": {
      await db.update(notifications).set({ read: true }).where(eq(notifications.parentId, parent.id));
      return NextResponse.json({ ok: true });
    }

    default:
      return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  }
}
