import type { Metadata } from "next";
import Link from "next/link";
import { getAllElves } from "@/lib/seed";
import Lights from "@/components/Lights";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Meet the 20 Elves of the North Pole",
  description:
    "Meet all 20 elf pen pals — 10 boy elves and 10 girl elves — each with their own personality, hobbies, workshop job, favourite treats and fun facts. Choose your child's elf friend today.",
  alternates: { canonical: "/elves" },
};

const THEME: Record<string, string> = {
  red: "from-red-600/25 to-red-900/25 border-red-300/30",
  green: "from-emerald-600/25 to-emerald-900/25 border-emerald-300/30",
  gold: "from-amber-500/25 to-amber-800/25 border-amber-300/30",
  blue: "from-sky-600/25 to-sky-900/25 border-sky-300/30",
};

export default async function ElvesPage() {
  const elves = await getAllElves();
  const boys = elves.filter((e) => e.gender === "boy");
  const girls = elves.filter((e) => e.gender === "girl");

  const ld = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    name: "North Pole Elf Pen Pals",
    itemListElement: elves.map((e, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: e.name,
      description: e.tagline,
    })),
  };

  const Card = ({ elf }: { elf: (typeof elves)[number] }) => (
    <article
      className={`rounded-3xl border bg-gradient-to-b p-5 backdrop-blur transition hover:-translate-y-1 ${
        THEME[elf.theme] ?? THEME.red
      }`}
    >
      <div className="flex items-start gap-3">
        <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-white/15 text-3xl">
          {elf.emoji}
        </div>
        <div>
          <h3 className="font-display text-xl font-bold text-amber-200">{elf.name}</h3>
          <p className="text-xs italic text-blue-50/80">{elf.tagline}</p>
        </div>
      </div>
      <p className="mt-3 text-sm text-blue-50/90">{elf.bio}</p>
      <dl className="mt-3 space-y-1 text-xs text-blue-50/85">
        <div><dt className="inline font-bold text-amber-200">Personality: </dt><dd className="inline">{elf.personality}</dd></div>
        <div><dt className="inline font-bold text-amber-200">Hobbies: </dt><dd className="inline">{elf.hobbies}</dd></div>
        <div><dt className="inline font-bold text-amber-200">Christmas job: </dt><dd className="inline">{elf.job}</dd></div>
        <div><dt className="inline font-bold text-amber-200">Favourite treat: </dt><dd className="inline">{elf.treats}</dd></div>
        <div><dt className="inline font-bold text-amber-200">Fun fact: </dt><dd className="inline">{elf.funFact}</dd></div>
      </dl>
      <p className="mt-3 font-hand text-base text-white">&ldquo;{elf.catchphrase}&rdquo;</p>
    </article>
  );

  return (
    <main className="min-h-screen">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} />
      <Lights bulbs={40} />
      <div className="mx-auto max-w-6xl px-4 py-10">
        <Link href="/" className="text-sm text-amber-200 hover:underline">← Back to the North Pole</Link>
        <h1 className="mt-3 font-display text-4xl font-bold text-white sm:text-5xl">
          Meet the <span className="gold-text">20 Elves</span>
        </h1>
        <p className="mt-2 max-w-2xl text-blue-50/85">
          Every elf has a real job at Santa&apos;s workshop, a personality all their own, and a whole lot of
          stories to share. Which one will your child choose?
        </p>
        <Link
          href="/kid/register"
          className="mt-5 inline-block rounded-2xl bg-gradient-to-b from-red-500 to-red-700 px-6 py-3 font-bold text-white shadow-xl ring-2 ring-white/30"
        >
          🎁 Choose my elf friend
        </Link>

        <h2 className="mt-12 font-display text-2xl font-bold text-amber-200">🧝‍♂️ Boy Elves</h2>
        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {boys.map((elf) => <Card key={elf.id} elf={elf} />)}
        </div>

        <h2 className="mt-12 font-display text-2xl font-bold text-amber-200">🧝‍♀️ Girl Elves</h2>
        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {girls.map((elf) => <Card key={elf.id} elf={elf} />)}
        </div>
      </div>
    </main>
  );
}
