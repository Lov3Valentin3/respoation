import { redirect, notFound } from "next/navigation";
import Link from "next/link";
import { db } from "@/db";
import { certificates } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { getCurrentChild } from "@/lib/auth";
import { CERTIFICATE_CATALOG } from "@/lib/elf-data";
import PrintButton from "@/components/PrintButton";

export const dynamic = "force-dynamic";

export default async function CertificatePage({ params }: { params: Promise<{ key: string }> }) {
  const { key } = await params;
  const current = await getCurrentChild();
  if (!current) redirect("/kid/login");
  const meta = CERTIFICATE_CATALOG.find((c) => c.key === key);
  if (!meta) notFound();

  const rows = await db
    .select()
    .from(certificates)
    .where(and(eq(certificates.childId, current.child.id), eq(certificates.key, key)))
    .limit(1);
  if (!rows[0]) redirect("/kid/dashboard");

  const { child, elf } = current;
  const date = new Date(rows[0].unlockedAt).toLocaleDateString(undefined, {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  return (
    <main className="min-h-screen px-4 py-8">
      <div className="no-print mx-auto mb-4 flex max-w-3xl items-center justify-between">
        <Link href="/kid/dashboard" className="text-sm text-amber-200 hover:underline">
          ← Back to dashboard
        </Link>
        <PrintButton />
      </div>

      <div className="mx-auto max-w-3xl bg-white p-3 shadow-2xl">
        <div className="candy-border p-8 text-center text-[#3a2a1a]">
          <p className="text-xs uppercase tracking-[0.4em] text-red-700">Official North Pole Document</p>
          <div className="mt-3 text-5xl">🏅</div>
          <h1 className="mt-3 font-display text-3xl font-bold text-red-800 sm:text-4xl">{meta.title}</h1>
          <p className="mt-4 text-sm">This certificate is proudly presented to</p>
          <p className="font-hand mt-2 text-5xl text-emerald-800">{child.firstName}</p>
          <p className="mx-auto mt-4 max-w-xl text-sm leading-relaxed">
            {meta.blurb} For showing wonderful kindness, imagination and Christmas spirit, and for being a true
            friend to {elf?.name ?? "the elves"} of Santa&apos;s workshop.
          </p>
          <div className="mt-8 flex items-end justify-between gap-4 text-left">
            <div>
              <p className="font-hand text-2xl text-red-800">Santa Claus</p>
              <div className="mt-1 w-40 border-t border-[#3a2a1a]/40 pt-1 text-[10px] uppercase tracking-widest">
                Santa Claus · North Pole
              </div>
            </div>
            <div className="text-4xl">🎅</div>
            <div className="text-right">
              <p className="font-hand text-2xl text-emerald-800">{elf?.name ?? "Elf Mail"}</p>
              <div className="mt-1 w-40 border-t border-[#3a2a1a]/40 pt-1 text-[10px] uppercase tracking-widest">
                Elf Pen Pal · {date}
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
