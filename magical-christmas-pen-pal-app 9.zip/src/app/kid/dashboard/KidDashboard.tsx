"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import type { Child, Elf, Letter, CertificateRow, VideoRow, AchievementRow } from "@/db/schema";
import Countdown from "@/components/Countdown";
import Lights from "@/components/Lights";
import Games from "@/components/Games";
import ElfVideo from "@/components/ElfVideo";
import { CERTIFICATE_CATALOG } from "@/lib/elf-data";

type Props = {
  child: Child;
  elf: Elf | null;
  initialLetters: Letter[];
  certificates: CertificateRow[];
  videos: VideoRow[];
  achievements: AchievementRow[];
  quote: string;
};

const TABS = [
  { key: "home", label: "Home", icon: "🏠" },
  { key: "write", label: "Write a Letter", icon: "✍️" },
  { key: "inbox", label: "Inbox", icon: "💌" },
  { key: "videos", label: "Elf Videos", icon: "🎬" },
  { key: "certificates", label: "Certificates", icon: "🏅" },
  { key: "games", label: "Games", icon: "🎮" },
];

export default function KidDashboard({
  child,
  elf,
  initialLetters,
  certificates,
  videos,
  achievements,
  quote,
}: Props) {
  const router = useRouter();
  const [tab, setTab] = useState("home");
  const [letters, setLetters] = useState<Letter[]>(initialLetters);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [flash, setFlash] = useState<string | null>(null);
  const [openLetter, setOpenLetter] = useState<Letter | null>(initialLetters[0] ?? null);

  const elfName = elf?.name ?? "your elf";
  const elfEmoji = elf?.emoji ?? "🧝";
  const elfFirst = elfName.split(" ")[0];

  async function send() {
    if (draft.trim().length < 2) return;
    setSending(true);
    setFlash(null);
    const res = await fetch("/api/letters", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ body: draft }),
    });
    const data = await res.json();
    setSending(false);
    if (!res.ok) {
      setFlash(data.error ?? "Your letter got stuck in a snowdrift. Try again!");
      return;
    }
    const now = new Date();
    const mine: Letter = {
      id: Math.random(),
      childId: child.id,
      elfId: child.elfId,
      sender: "child",
      body: draft,
      status: "delivered",
      read: true,
      createdAt: now,
    };
    const next = [mine, ...letters];
    if (data.reply) {
      next.unshift({ ...mine, id: Math.random() + 1, sender: "elf", body: data.reply, read: false });
    }
    setLetters(next);
    setDraft("");
    setFlash(
      data.reply
        ? `${elfFirst} wrote back! Open your inbox 💌`
        : "Your letter is on its way to the North Pole! Your grown-up will help your elf reply.",
    );
    setOpenLetter(next[0]);
    setTab("inbox");
    router.refresh();
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  }

  const unlockedKeys = new Set(certificates.map((c) => c.key));
  const badges = achievements.map((a) => a.badge);

  return (
    <main className="min-h-screen pb-16">
      <div className="sticky top-0 z-40 bg-[#0b1f3a]/85 backdrop-blur">
        <Lights bulbs={40} />
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <span className="text-3xl">{elfEmoji}</span>
            <div>
              <p className="font-display text-lg font-bold text-amber-200">Hi {child.firstName}!</p>
              <p className="text-xs text-blue-100/70">Pen pals with {elfName}</p>
            </div>
          </div>
          <button onClick={logout} className="rounded-full bg-white/12 px-4 py-2 text-sm text-white hover:bg-white/20">
            Log out
          </button>
        </div>
        <div className="mx-auto flex max-w-6xl gap-2 overflow-x-auto px-4 pb-3">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`shrink-0 rounded-full px-4 py-2 text-sm font-semibold transition ${
                tab === t.key ? "bg-red-600 text-white shadow" : "bg-white/10 text-blue-50 hover:bg-white/20"
              }`}
            >
              {t.icon} {t.label}
            </button>
          ))}
        </div>
      </div>

      <div className="mx-auto max-w-6xl px-4 py-6">
        {flash && (
          <div className="mb-4 rounded-2xl border border-emerald-300/40 bg-emerald-500/15 px-4 py-3 text-emerald-100">
            {flash}
          </div>
        )}

        {tab === "home" && (
          <div className="grid gap-4 lg:grid-cols-3">
            <div className="glass rounded-3xl p-6 lg:col-span-2">
              <h2 className="font-display text-2xl font-bold text-white">
                Your friendship with {elfFirst} {elfEmoji}
              </h2>
              <p className="mt-2 text-blue-50/85">{elf?.bio}</p>
              <div className="mt-4 grid grid-cols-3 gap-3 text-center">
                <div className="rounded-2xl bg-white/10 p-3">
                  <p className="gold-text font-display text-3xl font-bold">{child.lettersSent}</p>
                  <p className="text-xs text-blue-50/70">Letters sent</p>
                </div>
                <div className="rounded-2xl bg-white/10 p-3">
                  <p className="gold-text font-display text-3xl font-bold">{certificates.length}</p>
                  <p className="text-xs text-blue-50/70">Certificates</p>
                </div>
                <div className="rounded-2xl bg-white/10 p-3">
                  <p className="gold-text font-display text-3xl font-bold">{badges.length}</p>
                  <p className="text-xs text-blue-50/70">Badges</p>
                </div>
              </div>
              <button
                onClick={() => setTab("write")}
                className="mt-5 w-full rounded-2xl bg-gradient-to-b from-red-500 to-red-700 px-6 py-4 text-lg font-bold text-white shadow-xl ring-2 ring-white/25"
              >
                ✍️ Write to {elfFirst}
              </button>
            </div>

            <div className="space-y-4">
              <div className="glass rounded-3xl p-5">
                <p className="text-xs uppercase tracking-widest text-amber-200/80">Countdown to Christmas</p>
                <div className="mt-2">
                  <Countdown compact />
                </div>
              </div>
              <div className="glass rounded-3xl p-5">
                <p className="text-xs uppercase tracking-widest text-amber-200/80">Today&apos;s magic</p>
                <p className="mt-1 font-hand text-xl text-white">&ldquo;{quote}&rdquo;</p>
              </div>
              <div className="glass rounded-3xl p-5">
                <p className="text-xs uppercase tracking-widest text-amber-200/80">Your magic code</p>
                <p className="font-display text-xl font-bold text-emerald-300">{child.magicCode}</p>
                <p className="mt-1 text-xs text-blue-50/60">Use this to log in next time.</p>
              </div>
            </div>
          </div>
        )}

        {tab === "write" && (
          <div className="mx-auto max-w-3xl">
            <div className="paper rounded-3xl p-6 sm:p-8">
              <h2 className="font-hand text-2xl text-red-800">Dear {elfFirst},</h2>
              <textarea
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                rows={12}
                placeholder="Tell your elf about your day, your favourite things, a joke, or ask them a question..."
                className="font-hand mt-3 w-full resize-none rounded-2xl border-2 border-dashed border-red-300 bg-white/70 p-4 text-lg text-[#3a2a1a] outline-none focus:border-emerald-500"
              />
              <p className="font-hand mt-2 text-right text-xl text-red-800">Love, {child.firstName}</p>
              <button
                disabled={sending || draft.trim().length < 2}
                onClick={send}
                className="mt-4 w-full rounded-2xl bg-emerald-700 px-6 py-4 text-lg font-bold text-white shadow-lg hover:bg-emerald-600 disabled:opacity-40"
              >
                {sending ? "✨ Sending by reindeer express..." : "📮 Send to the North Pole"}
              </button>
              {child.paused && (
                <p className="mt-3 rounded-xl bg-amber-100 px-4 py-2 text-center text-sm text-amber-900">
                  Your grown-up has paused replies for now — your letters are still safely saved!
                </p>
              )}
            </div>
            <div className="glass mt-4 rounded-3xl p-5">
              <p className="text-sm font-bold text-amber-200">Need an idea? Try one of these!</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {[
                  "Tell me about the reindeer!",
                  "What's your favourite treat?",
                  "Guess what I did today...",
                  "Here's my best joke:",
                  "What do elves do in summer?",
                  "Can you tell Santa something for me?",
                ].map((p) => (
                  <button
                    key={p}
                    onClick={() => setDraft((d) => (d ? `${d} ${p}` : p))}
                    className="rounded-full bg-white/12 px-3 py-1.5 text-xs text-white hover:bg-white/25"
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {tab === "inbox" && (
          <div className="grid gap-4 lg:grid-cols-[320px_1fr]">
            <div className="space-y-2">
              <h2 className="font-display text-xl font-bold text-white">Your mailbox ({letters.length})</h2>
              <div className="max-h-[32rem] space-y-2 overflow-y-auto pr-1">
                {letters.map((l) => (
                  <button
                    key={l.id}
                    onClick={() => setOpenLetter(l)}
                    className={`w-full rounded-2xl border p-3 text-left transition ${
                      openLetter?.id === l.id
                        ? "border-amber-300 bg-amber-300/20"
                        : "border-white/15 bg-white/8 hover:bg-white/15"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{l.sender === "elf" ? "💌" : "✉️"}</span>
                      <span className="text-sm font-bold text-amber-200">
                        {l.sender === "elf" ? elfFirst : child.firstName}
                      </span>
                      <span className="ml-auto text-[10px] text-blue-100/60">
                        {new Date(l.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    <p className="mt-1 line-clamp-2 text-xs text-blue-50/75">{l.body.slice(0, 90)}...</p>
                  </button>
                ))}
                {letters.length === 0 && <p className="text-sm text-blue-50/60">No letters yet — write the first one!</p>}
              </div>
            </div>
            <div>
              {openLetter ? (
                <article className="paper rounded-3xl p-6 sm:p-9">
                  <div className="mb-3 flex items-center justify-between text-xs font-semibold uppercase tracking-widest text-red-800/70">
                    <span>{openLetter.sender === "elf" ? `From ${elfName}` : `From ${child.firstName}`}</span>
                    <span>{new Date(openLetter.createdAt).toLocaleString()}</span>
                  </div>
                  <div className="font-hand whitespace-pre-wrap text-[19px] leading-relaxed text-[#40301f]">
                    {openLetter.body}
                  </div>
                </article>
              ) : (
                <div className="glass rounded-3xl p-10 text-center text-blue-50/70">Pick an envelope to open it ✨</div>
              )}
            </div>
          </div>
        )}

        {tab === "videos" && (
          <div>
            <h2 className="font-display text-2xl font-bold text-white">Videos from {elfFirst} 🎬</h2>
            <p className="mt-1 text-blue-50/80">
              Personalised clips filmed at the North Pole — with your name in them, {child.firstName}!
            </p>
            <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {videos.map((v) => (
                <ElfVideo key={v.id} scene={v.scene} title={v.title} name={child.firstName} elfEmoji={elfEmoji} />
              ))}
            </div>
            <div className="glass mt-5 rounded-3xl p-5 text-center text-sm text-blue-50/80">
              🔒 Keep writing letters to unlock more videos. Premium AI-personalised video messages are available
              in the parent portal.
            </div>
          </div>
        )}

        {tab === "certificates" && (
          <div>
            <h2 className="font-display text-2xl font-bold text-white">Your certificates 🏅</h2>
            <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {CERTIFICATE_CATALOG.map((c) => {
                const unlocked = unlockedKeys.has(c.key);
                return (
                  <div
                    key={c.key}
                    className={`rounded-3xl border p-5 ${
                      unlocked ? "border-amber-300/60 bg-amber-300/15" : "border-white/12 bg-white/6 opacity-70"
                    }`}
                  >
                    <div className="text-3xl">{unlocked ? "🏅" : "🔒"}</div>
                    <h3 className="mt-2 font-display text-lg font-bold text-amber-200">{c.title}</h3>
                    <p className="text-xs text-blue-50/80">{c.blurb}</p>
                    {unlocked ? (
                      <Link
                        href={`/kid/certificate/${c.key}`}
                        className="mt-3 inline-block rounded-full bg-emerald-700 px-4 py-2 text-sm font-bold text-white"
                      >
                        View & print
                      </Link>
                    ) : (
                      <p className="mt-3 text-xs text-blue-50/70">
                        {c.premium
                          ? "Premium — ask a grown-up to unlock in the parent portal."
                          : `Write ${Math.max(0, c.requirement - child.lettersSent)} more letter(s) to unlock.`}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {tab === "games" && (
          <div>
            <h2 className="font-display text-2xl font-bold text-white">North Pole games 🎮</h2>
            <p className="mb-4 mt-1 text-blue-50/80">Earn badges and your elf will hear all about it!</p>
            <Games childName={child.firstName} elfEmoji={elfEmoji} earned={badges} />
          </div>
        )}
      </div>
    </main>
  );
}
