import { redirect } from "next/navigation";
import type { Metadata } from "next";
import { db } from "@/db";
import { letters, certificates, videos, achievements } from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { getCurrentChild } from "@/lib/auth";
import { DAILY_QUOTES } from "@/lib/elf-data";
import KidDashboard from "./KidDashboard";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "My North Pole Dashboard",
  description: "Write to your elf, read your letters, watch elf videos, print certificates and play games.",
  robots: { index: false, follow: false },
};

export default async function Page() {
  const current = await getCurrentChild();
  if (!current) redirect("/kid/login");
  const { child, elf } = current;

  const [letterRows, certRows, videoRows, achievementRows] = await Promise.all([
    db.select().from(letters).where(eq(letters.childId, child.id)).orderBy(desc(letters.createdAt)),
    db.select().from(certificates).where(eq(certificates.childId, child.id)),
    db.select().from(videos).where(eq(videos.childId, child.id)),
    db.select().from(achievements).where(eq(achievements.childId, child.id)),
  ]);

  const dayIndex = Math.floor(Date.now() / 86400000) % DAILY_QUOTES.length;

  return (
    <KidDashboard
      child={child}
      elf={elf}
      initialLetters={letterRows}
      certificates={certRows}
      videos={videoRows}
      achievements={achievementRows}
      quote={DAILY_QUOTES[dayIndex]}
    />
  );
}
