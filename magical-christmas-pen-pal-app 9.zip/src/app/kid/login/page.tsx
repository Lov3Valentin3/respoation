"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import Lights from "@/components/Lights";

export default function KidLoginPage() {
  const router = useRouter();
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const res = await fetch("/api/kid/auth", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode: "login", magicCode: code }),
    });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) return setError(data.error ?? "Try again!");
    router.push("/kid/dashboard");
    router.refresh();
  }

  return (
    <main className="min-h-screen">
      <Lights bulbs={36} />
      <div className="mx-auto max-w-md px-4 py-14">
        <Link href="/" className="text-sm text-amber-200 hover:underline">← Back home</Link>
        <form onSubmit={submit} className="paper mt-4 rounded-3xl p-8">
          <div className="text-center text-5xl">🔔</div>
          <h1 className="mt-2 text-center font-display text-3xl font-bold text-red-800">Welcome back!</h1>
          <p className="mt-2 text-center text-sm text-[#4a3524]">
            Type your magic code and your elf will open the mailbox.
          </p>
          <input
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            placeholder="SOFIA-SNOW123"
            className="mt-6 w-full rounded-2xl border-4 border-dashed border-red-300 bg-white px-4 py-4 text-center font-display text-2xl tracking-wider text-emerald-800 outline-none focus:border-emerald-500"
          />
          {error && <p className="mt-3 rounded-xl bg-red-100 px-4 py-2 text-center text-sm text-red-700">{error}</p>}
          <button
            disabled={loading}
            className="mt-5 w-full rounded-2xl bg-emerald-700 px-6 py-4 text-lg font-bold text-white shadow-lg hover:bg-emerald-600 disabled:opacity-50"
          >
            {loading ? "Unlocking the North Pole..." : "✨ Let me in!"}
          </button>
          <p className="mt-4 text-center text-sm text-[#4a3524]">
            No elf yet?{" "}
            <Link href="/kid/register" className="font-bold text-red-700 underline">
              Choose your elf friend
            </Link>
          </p>
        </form>
      </div>
    </main>
  );
}
