"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import type { Elf } from "@/db/schema";
import Lights from "@/components/Lights";

const COLORS = [
  { name: "Red", hex: "#e53935" },
  { name: "Green", hex: "#2e7d32" },
  { name: "Blue", hex: "#1e88e5" },
  { name: "Gold", hex: "#f2c14e" },
  { name: "Pink", hex: "#ec407a" },
  { name: "Purple", hex: "#8e24aa" },
  { name: "Orange", hex: "#fb8c00" },
  { name: "Rainbow", hex: "linear-gradient(90deg,#e53935,#fb8c00,#fdd835,#43a047,#1e88e5,#8e24aa)" },
];

const ACTIVITIES = [
  "Decorating the tree",
  "Baking cookies",
  "Building snowmen",
  "Singing carols",
  "Opening presents",
  "Watching Christmas movies",
  "Sledding",
  "Making paper snowflakes",
];

export default function KidRegisterForm({ elves }: { elves: Elf[] }) {
  const router = useRouter();
  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    firstName: "",
    age: 7,
    favoriteColor: "",
    favoriteActivity: "",
    christmasWish: "",
    birthday: "",
    elfId: 0,
  });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [magicCode, setMagicCode] = useState<string | null>(null);
  const [fromParent, setFromParent] = useState(false);
  const [filter, setFilter] = useState<"all" | "boy" | "girl">("all");

  const shown = elves.filter((e) => filter === "all" || e.gender === filter);
  const chosen = elves.find((e) => e.id === form.elfId);

  const canContinue =
    step === 0
      ? form.firstName.trim().length > 0 && form.age > 0
      : step === 1
        ? Boolean(form.favoriteColor && form.favoriteActivity)
        : Boolean(form.elfId);

  async function submit() {
    setLoading(true);
    setError("");
    const res = await fetch("/api/kid/auth", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode: "register", ...form }),
    });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) {
      setError(data.error ?? "Something went wobbly. Try again!");
      return;
    }
    setFromParent(Boolean(data.fromParent));
    setMagicCode(data.magicCode);
  }

  if (magicCode) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-16 text-center">
        <div className="paper pop-in rounded-3xl p-8">
          <div className="text-6xl">🎉</div>
          <h1 className="mt-3 font-display text-3xl font-bold text-red-800">You have an elf friend!</h1>
          <p className="mt-3 text-[#4a3524]">
            {chosen?.name} is already writing your first letter. Keep this magic code safe — it&apos;s how you
            log in next time.
          </p>
          <div className="mt-5 rounded-2xl border-4 border-dashed border-red-400 bg-white/70 px-6 py-5">
            <p className="text-xs uppercase tracking-widest text-red-700">Your magic code</p>
            <p className="font-display text-3xl font-bold tracking-wider text-emerald-800">{magicCode}</p>
          </div>
          <button
            onClick={() => router.push(fromParent ? "/parent/dashboard" : "/kid/dashboard")}
            className="mt-6 w-full rounded-2xl bg-emerald-700 px-6 py-4 text-lg font-bold text-white shadow-lg hover:bg-emerald-600"
          >
            {fromParent ? "👨‍👩‍👧 Back to the parent portal" : "✨ Open my North Pole dashboard"}
          </button>
          <p className="mt-3 text-xs text-[#6b5540]">
            Grown-ups: <Link href="/parent/register" className="underline">create a parent account</Link> to see
            every letter and manage the magic.
          </p>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen">
      <Lights bulbs={36} />
      <div className="mx-auto max-w-4xl px-4 py-8">
        <Link href="/" className="text-sm text-amber-200 hover:underline">← Back home</Link>
        <div className="mt-4 mb-6 flex items-center gap-2">
          {["About you", "Favourites", "Pick your elf"].map((label, i) => (
            <div key={label} className="flex-1">
              <div className={`h-2 rounded-full ${i <= step ? "bg-amber-400" : "bg-white/15"}`} />
              <p className={`mt-1 text-xs ${i <= step ? "text-amber-200" : "text-blue-100/50"}`}>{label}</p>
            </div>
          ))}
        </div>

        <div className="glass rounded-3xl p-6 sm:p-8">
          {step === 0 && (
            <div className="pop-in">
              <h1 className="font-display text-3xl font-bold text-white">Hello! What&apos;s your name?</h1>
              <p className="mt-1 text-blue-50/80">Your elf wants to write it at the top of every letter.</p>
              <label className="mt-6 block text-sm font-semibold text-amber-200">First name</label>
              <input
                value={form.firstName}
                onChange={(e) => setForm({ ...form, firstName: e.target.value })}
                placeholder="e.g. Sofia"
                className="mt-1 w-full rounded-2xl border border-white/20 bg-white/90 px-4 py-4 text-xl text-slate-900 outline-none focus:ring-4 focus:ring-amber-300/50"
              />
              <label className="mt-5 block text-sm font-semibold text-amber-200">How old are you?</label>
              <div className="mt-2 flex flex-wrap gap-2">
                {Array.from({ length: 12 }, (_, i) => i + 1).map((a) => (
                  <button
                    key={a}
                    onClick={() => setForm({ ...form, age: a })}
                    className={`h-12 w-12 rounded-full text-lg font-bold transition ${
                      form.age === a ? "bg-red-600 text-white ring-4 ring-amber-300" : "bg-white/15 text-white hover:bg-white/25"
                    }`}
                  >
                    {a}
                  </button>
                ))}
              </div>
              <label className="mt-5 block text-sm font-semibold text-amber-200">
                When is your birthday? (optional — your elf will celebrate!)
              </label>
              <input
                value={form.birthday}
                onChange={(e) => setForm({ ...form, birthday: e.target.value })}
                placeholder="e.g. March 14"
                className="mt-1 w-full rounded-2xl border border-white/20 bg-white/90 px-4 py-3 text-slate-900 outline-none focus:ring-4 focus:ring-amber-300/50"
              />
            </div>
          )}

          {step === 1 && (
            <div className="pop-in">
              <h1 className="font-display text-3xl font-bold text-white">Tell your elf your favourites</h1>
              <label className="mt-6 block text-sm font-semibold text-amber-200">Favourite colour</label>
              <div className="mt-2 grid grid-cols-4 gap-3 sm:grid-cols-8">
                {COLORS.map((c) => (
                  <button
                    key={c.name}
                    onClick={() => setForm({ ...form, favoriteColor: c.name })}
                    title={c.name}
                    className={`h-14 rounded-2xl border-2 transition ${
                      form.favoriteColor === c.name ? "scale-110 border-amber-300 ring-4 ring-amber-300/40" : "border-white/30"
                    }`}
                    style={{ background: c.hex }}
                  />
                ))}
              </div>
              <p className="mt-2 text-sm text-blue-50/80">{form.favoriteColor || "Tap a colour"}</p>

              <label className="mt-6 block text-sm font-semibold text-amber-200">Favourite Christmas activity</label>
              <div className="mt-2 grid gap-2 sm:grid-cols-2">
                {ACTIVITIES.map((a) => (
                  <button
                    key={a}
                    onClick={() => setForm({ ...form, favoriteActivity: a })}
                    className={`rounded-2xl px-4 py-3 text-left font-semibold transition ${
                      form.favoriteActivity === a
                        ? "bg-emerald-600 text-white ring-2 ring-amber-300"
                        : "bg-white/12 text-white hover:bg-white/20"
                    }`}
                  >
                    {a}
                  </button>
                ))}
              </div>

              <label className="mt-6 block text-sm font-semibold text-amber-200">
                What do you wish for this Christmas? (optional)
              </label>
              <input
                value={form.christmasWish}
                onChange={(e) => setForm({ ...form, christmasWish: e.target.value })}
                placeholder="e.g. a red bicycle"
                className="mt-1 w-full rounded-2xl border border-white/20 bg-white/90 px-4 py-3 text-slate-900 outline-none focus:ring-4 focus:ring-amber-300/50"
              />
            </div>
          )}

          {step === 2 && (
            <div className="pop-in">
              <h1 className="font-display text-3xl font-bold text-white">Choose your elf friend</h1>
              <div className="mt-3 flex gap-2">
                {(["all", "boy", "girl"] as const).map((f) => (
                  <button
                    key={f}
                    onClick={() => setFilter(f)}
                    className={`rounded-full px-4 py-1.5 text-sm font-semibold capitalize ${
                      filter === f ? "bg-amber-400 text-red-900" : "bg-white/12 text-white"
                    }`}
                  >
                    {f === "all" ? "All 20" : `${f} elves`}
                  </button>
                ))}
              </div>
              <div className="mt-4 grid max-h-[26rem] gap-3 overflow-y-auto pr-1 sm:grid-cols-2">
                {shown.map((elf) => (
                  <button
                    key={elf.id}
                    onClick={() => setForm({ ...form, elfId: elf.id })}
                    className={`rounded-2xl border p-4 text-left transition ${
                      form.elfId === elf.id
                        ? "border-amber-300 bg-amber-300/20 ring-2 ring-amber-300"
                        : "border-white/15 bg-white/8 hover:bg-white/15"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-3xl">{elf.emoji}</span>
                      <div>
                        <p className="font-display text-lg font-bold text-amber-200">{elf.name}</p>
                        <p className="text-[11px] text-blue-50/80">{elf.tagline}</p>
                      </div>
                    </div>
                    <p className="mt-2 text-xs text-blue-50/85">
                      <b className="text-amber-200">Personality:</b> {elf.personality}
                    </p>
                    <p className="text-xs text-blue-50/85">
                      <b className="text-amber-200">Loves:</b> {elf.hobbies}
                    </p>
                    <p className="text-xs text-blue-50/85">
                      <b className="text-amber-200">Job:</b> {elf.job}
                    </p>
                  </button>
                ))}
              </div>
              {chosen && (
                <p className="mt-3 font-hand text-lg text-amber-100">
                  {chosen.name} is waving at you! {chosen.emoji}
                </p>
              )}
            </div>
          )}

          {error && <p className="mt-4 rounded-xl bg-red-500/20 px-4 py-2 text-sm text-red-100">{error}</p>}

          <div className="mt-7 flex gap-3">
            {step > 0 && (
              <button
                onClick={() => setStep(step - 1)}
                className="rounded-2xl border border-white/25 px-5 py-3 font-semibold text-white hover:bg-white/10"
              >
                ← Back
              </button>
            )}
            <button
              disabled={!canContinue || loading}
              onClick={() => (step === 2 ? submit() : setStep(step + 1))}
              className="flex-1 rounded-2xl bg-gradient-to-b from-red-500 to-red-700 px-6 py-4 text-lg font-bold text-white shadow-xl ring-2 ring-white/25 transition disabled:opacity-40"
            >
              {loading ? "Sending to the North Pole..." : step === 2 ? "🎄 Start my friendship!" : "Next →"}
            </button>
          </div>
        </div>
      </div>
    </main>
  );
}
