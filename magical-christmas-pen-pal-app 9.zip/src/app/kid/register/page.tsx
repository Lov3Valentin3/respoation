import type { Metadata } from "next";
import { getAllElves } from "@/lib/seed";
import KidRegisterForm from "./KidRegisterForm";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Choose Your Elf Friend — Kid Registration",
  description:
    "Tell your elf about yourself and choose your very own North Pole pen pal from 20 magical elves. Free to start.",
  alternates: { canonical: "/kid/register" },
};

export default async function KidRegisterPage() {
  const elves = await getAllElves();
  return <KidRegisterForm elves={elves} />;
}
