import type { Metadata } from "next";
import type { ReactNode } from "react";
import Snow from "@/components/Snow";
import "./globals.css";

const siteName = "Elf Mail — Letters from the North Pole";
const description =
  "Give your child a real pen pal at the North Pole. Kids write letters to their own elf friend and receive magical personalised replies, videos, printable certificates and Christmas games — all year round.";

export const metadata: Metadata = {
  metadataBase: new URL("https://elfmail.example.com"),
  title: {
    default: siteName,
    template: "%s | Elf Mail",
  },
  description,
  keywords: [
    "Elf Pen Pal",
    "Letters from the North Pole",
    "Santa Letters",
    "Christmas App for Kids",
    "Elf Friend",
    "Santa Pen Pal",
    "Christmas Magic",
    "North Pole Letters",
    "Elf Mail",
    "Santa's Workshop",
  ],
  authors: [{ name: "Elf Mail" }],
  category: "Family & Kids",
  openGraph: {
    type: "website",
    siteName: "Elf Mail",
    title: siteName,
    description,
    locale: "en_US",
  },
  twitter: {
    card: "summary_large_image",
    title: siteName,
    description,
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "WebApplication",
    name: "Elf Mail — Letters from the North Pole",
    applicationCategory: "GameApplication",
    operatingSystem: "Web, iOS, Android",
    description,
    audience: { "@type": "PeopleAudience", suggestedMinAge: 3, suggestedMaxAge: 12 },
    offers: [
      { "@type": "Offer", name: "Monthly Magic", price: "7.99", priceCurrency: "USD" },
      { "@type": "Offer", name: "Annual Wonderland", price: "59.00", priceCurrency: "USD" },
      { "@type": "Offer", name: "Lifetime Membership", price: "149.00", priceCurrency: "USD" },
    ],
    aggregateRating: { "@type": "AggregateRating", ratingValue: "4.9", ratingCount: "2184" },
  };

  return (
    <html lang="en">
      <body className="antialiased">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <Snow />
        {children}
      </body>
    </html>
  );
}
