import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Elf Mail — Letters from the North Pole",
    short_name: "Elf Mail",
    description: "A magical Christmas pen pal app where kids write letters to their own elf friend.",
    start_url: "/",
    display: "standalone",
    orientation: "portrait",
    background_color: "#0b1f3a",
    theme_color: "#c62828",
    categories: ["kids", "education", "entertainment"],
    icons: [
      { src: "/icon.svg", sizes: "any", type: "image/svg+xml", purpose: "any" },
    ],
  };
}
