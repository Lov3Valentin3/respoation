import Link from "next/link";
import type { Metadata } from "next";
import Lights from "@/components/Lights";
import Countdown from "@/components/Countdown";
import { getAllElves } from "@/lib/seed";
import { DAILY_QUOTES } from "@/lib/elf-data";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Elf Mail — Your Child's Own Pen Pal at the North Pole",
  description:
    "A magical Christmas pen pal app for kids ages 3–12. Choose from 20 elf friends, exchange personalised letters all year, unlock certificates, watch North Pole videos and play festive games.",
  alternates: { canonical: "/" },
};

const FAQS = [
  {
    q: "What is Elf Mail?",
    a: "Elf Mail is a magical pen pal app where children write letters to their very own elf at the North Pole and receive warm, personalised replies that remember everything about them.",
  },
  {
    q: "Is it safe for children?",
    a: "Yes. Parents create the account, see every letter sent and received, choose whether replies come from the elf, the parent, or both, and can pause conversations any time.",
  },
  {
    q: "What ages is it for?",
    a: "Elf Mail is designed for children ages 3 to 12, with big friendly buttons, read-aloud friendly letters and gentle, age-appropriate storytelling.",
  },
  {
    q: "Does it work all year?",
    a: "Absolutely! The North Pole never sleeps. Children can write to their elf any day of the year and watch the Christmas countdown together.",
  },
];

export default async function Home() {
  const elves = await getAllElves();
  const preview = elves.slice(0, 8);
  const quote = DAILY_QUOTES[new Date().getDate() % DAILY_QUOTES.length];

  const faqLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: FAQS.map((f) => ({
      "@type": "Question",
      name: f.q,
      acceptedAnswer: { "@type": "Answer", text: f.a },
    })),
  };

  return (
    <main className="relative overflow-hidden">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqLd) }} />
      <div className="sticky top-0 z-40 bg-[#0b1f3a]/80 backdrop-blur">
        <Lights bulbs={40} />
        <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <Link href="/" className="flex items-center gap-2 font-display text-xl font-bold text-amber-200">
            <span className="text-2xl">🎅</span> Elf<span className="gold-text">Mail</span>
          </Link>
          <div className="flex items-center gap-2 text-sm">
            <Link href="/elves" className="rounded-full px-3 py-1.5 text-amber-100 hover:bg-white/10">
              Meet the Elves
            </Link>
            <Link href="/pricing" className="rounded-full px-3 py-1.5 text-amber-100 hover:bg-white/10">
              Plans
            </Link>
            <Link
              href="/kid/login"
              className="rounded-full bg-red-600 px-4 py-1.5 font-semibold text-white shadow hover:bg-red-500"
            >
              Kid Login
            </Link>
          </div>
        </nav>
      </div>

      {/* HERO */}
      <section className="relative mx-auto max-w-6xl px-4 pt-10 pb-16">
        <div className="pointer-events-none absolute -left-16 top-24 text-[9rem] opacity-20 select-none">🎄</div>
        <div className="pointer-events-none absolute -right-10 top-52 text-[8rem] opacity-20 select-none">🦌</div>

        <div className="grid items-center gap-10 lg:grid-cols-2">
          <div className="pop-in">
            <span className="inline-flex items-center gap-2 rounded-full border border-amber-300/40 bg-amber-300/10 px-4 py-1 text-xs font-semibold uppercase tracking-widest text-amber-200">
              ✨ Live from the North Pole
            </span>
            <h1 className="mt-4 font-display text-4xl font-bold leading-tight text-white sm:text-6xl">
              Your child has a <span className="gold-text">real pen pal</span> at the North Pole
            </h1>
            <p className="mt-4 max-w-xl text-lg text-blue-50/90">
              Pick from 20 one-of-a-kind elf friends. Write letters all year long. Get magical replies that
              remember your name, your favourite things, your birthday and every inside joke.
            </p>

            <div className="mt-7 grid gap-3 sm:grid-cols-2">
              <Link
                href="/kid/register"
                className="rounded-2xl bg-gradient-to-b from-red-500 to-red-700 px-6 py-4 text-center text-lg font-bold text-white shadow-xl ring-2 ring-white/30 transition hover:scale-[1.02]"
              >
                🎁 Kid Register
              </Link>
              <Link
                href="/kid/login"
                className="rounded-2xl bg-gradient-to-b from-emerald-500 to-emerald-700 px-6 py-4 text-center text-lg font-bold text-white shadow-xl ring-2 ring-white/30 transition hover:scale-[1.02]"
              >
                🔔 Kid Login
              </Link>
              <Link
                href="/parent/register"
                className="rounded-2xl border border-amber-200/50 bg-white/10 px-6 py-4 text-center font-semibold text-amber-100 backdrop-blur transition hover:bg-white/20"
              >
                👨‍👩‍👧 Parent Register
              </Link>
              <Link
                href="/parent/login"
                className="rounded-2xl border border-amber-200/50 bg-white/10 px-6 py-4 text-center font-semibold text-amber-100 backdrop-blur transition hover:bg-white/20"
              >
                🔐 Parent Login
              </Link>
            </div>

            <div className="mt-8">
              <p className="mb-2 text-xs uppercase tracking-widest text-amber-200/80">Christmas is coming!</p>
              <Countdown />
            </div>
          </div>

          {/* The waiting letter */}
          <div className="relative float-soft">
            <div className="absolute -top-5 -left-4 z-10 rotate-[-8deg] rounded-lg bg-red-600 px-3 py-1 text-xs font-bold uppercase tracking-wider text-white shadow-lg">
              A letter is waiting for you!
            </div>
            <article className="paper rotate-[1.2deg] rounded-[22px] p-7 sm:p-9">
              <div className="mb-3 flex items-center justify-between text-xs font-semibold uppercase tracking-widest text-red-800/70">
                <span>North Pole · Workshop Wing 3</span>
                <span>🎄</span>
              </div>
              <h2 className="font-hand text-2xl text-red-800">Dear new friend,</h2>
              <div className="font-hand mt-3 space-y-3 text-[17px] leading-relaxed text-[#4a3524]">
                <p>
                  My name is Jingle and I make toy trains at Santa&apos;s workshop. Today, while I was sorting
                  the mail with Ivy, a little golden spark landed on an empty envelope — and that only ever
                  happens when somebody special is about to become a pen pal.
                </p>
                <p>
                  So I&apos;m writing to <em>you</em>. Would you like to be my friend? You can tell me anything:
                  your favourite colour, what you did today, the funniest joke you know. I&apos;ll write back with
                  news from the North Pole, secrets from the workshop, and maybe a story about the time I
                  accidentally wrapped Santa&apos;s boots.
                </p>
                <p>Write soon. My mailbox is already jingling with excitement!</p>
              </div>
              <p className="font-hand mt-5 text-xl text-red-800">Your friend, Jingle 🛷</p>
              <Link
                href="/kid/register"
                className="mt-6 block rounded-xl bg-emerald-700 px-5 py-3 text-center font-bold text-white shadow-lg transition hover:bg-emerald-600"
              >
                ✍️ Write back to Jingle
              </Link>
            </article>
          </div>
        </div>
      </section>

      {/* QUOTE */}
      <section className="mx-auto max-w-4xl px-4 pb-12">
        <div className="glass rounded-3xl px-6 py-5 text-center">
          <p className="text-xs uppercase tracking-widest text-amber-200/80">Today&apos;s sprinkle of magic</p>
          <p className="mt-1 font-display text-xl text-white sm:text-2xl">&ldquo;{quote}&rdquo;</p>
        </div>
      </section>

      {/* ELF PREVIEW */}
      <section className="mx-auto max-w-6xl px-4 pb-16">
        <h2 className="text-center font-display text-3xl font-bold text-white sm:text-4xl">
          Meet your <span className="gold-text">elf friend</span>
        </h2>
        <p className="mx-auto mt-2 max-w-2xl text-center text-blue-50/80">
          Twenty elves live at the North Pole — ten boys and ten girls — each with their own job, hobbies,
          favourite treats and personality.
        </p>
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
          {preview.map((elf) => (
            <div key={elf.id} className="glass rounded-3xl p-4 text-center transition hover:-translate-y-1">
              <div className="text-4xl">{elf.emoji}</div>
              <h3 className="mt-2 font-display text-lg font-bold text-amber-200">{elf.name.split(" ")[0]}</h3>
              <p className="text-xs text-blue-50/80">{elf.tagline}</p>
            </div>
          ))}
        </div>
        <div className="mt-6 text-center">
          <Link
            href="/elves"
            className="inline-block rounded-full border border-amber-200/50 px-6 py-3 font-semibold text-amber-100 hover:bg-white/10"
          >
            See all 20 elves →
          </Link>
        </div>
      </section>

      {/* FEATURES */}
      <section className="mx-auto max-w-6xl px-4 pb-16">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {[
            { icon: "💌", title: "Letters that remember", text: "Your elf remembers your name, favourite things, birthday, wishes and every inside joke." },
            { icon: "🎬", title: "Videos from your elf", text: "Peek inside the workshop, feed the reindeer and watch snow fall at the North Pole." },
            { icon: "🏅", title: "Printable certificates", text: "Nice List, Friend of the North Pole, Kindness Award and premium keepsakes." },
            { icon: "🎮", title: "10 festive mini games", text: "Memory, trivia, mazes, word search, colouring and more — with badges to earn." },
            { icon: "👨‍👩‍👧", title: "Full parent control", text: "See every letter, choose AI or parent-written replies, pause any time." },
            { icon: "📱", title: "Works everywhere", text: "Installable on iOS and Android, syncs instantly across every device." },
          ].map((f) => (
            <div key={f.title} className="glass rounded-3xl p-6">
              <div className="text-3xl">{f.icon}</div>
              <h3 className="mt-3 font-display text-xl font-bold text-amber-200">{f.title}</h3>
              <p className="mt-1 text-sm text-blue-50/85">{f.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="mx-auto max-w-4xl px-4 pb-20">
        <h2 className="mb-6 text-center font-display text-3xl font-bold text-white">Questions from grown-ups</h2>
        <div className="space-y-3">
          {FAQS.map((f) => (
            <details key={f.q} className="glass rounded-2xl p-5">
              <summary className="cursor-pointer font-semibold text-amber-200">{f.q}</summary>
              <p className="mt-2 text-sm text-blue-50/85">{f.a}</p>
            </details>
          ))}
        </div>
      </section>

      <footer className="border-t border-white/10 bg-[#08172c]/80 py-10 text-center text-sm text-blue-100/70">
        <Lights bulbs={30} />
        <p className="mt-4 font-display text-lg text-amber-200">Elf Mail — Letters from the North Pole</p>
        <p className="mt-2">Elf Pen Pal · Santa Letters · North Pole Letters · Christmas App for Kids</p>
        <div className="mt-4 flex justify-center gap-4">
          <Link href="/elves" className="hover:text-amber-200">Elves</Link>
          <Link href="/pricing" className="hover:text-amber-200">Plans</Link>
          <Link href="/parent/login" className="hover:text-amber-200">Parents</Link>
          <Link href="/kid/login" className="hover:text-amber-200">Kids</Link>
        </div>
        <p className="mt-4 text-xs text-blue-200/50">© {new Date().getFullYear()} Elf Mail. Made with cocoa at the North Pole.</p>
      </footer>
    </main>
  );
}
