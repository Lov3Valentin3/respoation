"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import type {
  Child,
  Elf,
  Letter,
  NotificationRow,
  SubscriptionRow,
  CertificateRow,
  AchievementRow,
} from "@/db/schema";
import Lights from "@/components/Lights";
import Countdown from "@/components/Countdown";
import { PLANS, ADDONS, CERTIFICATE_CATALOG } from "@/lib/elf-data";

type KidRow = { child: Child; elf: Elf | null };

type Props = {
  parentName: string;
  kids: KidRow[];
  letters: Letter[];
  notifications: NotificationRow[];
  subscription: SubscriptionRow | null;
  certificates: CertificateRow[];
  achievements: AchievementRow[];
};

const TABS = [
  { key: "children", label: "Children", icon: "👧" },
  { key: "letters", label: "Letters", icon: "💌" },
  { key: "controls", label: "Controls", icon: "🎛️" },
  { key: "plans", label: "Plans & Add-ons", icon: "💳" },
  { key: "notifications", label: "Notifications", icon: "🔔" },
  { key: "share", label: "Share the Magic", icon: "📣" },
];

const money = (cents: number) => `$${(cents / 100).toFixed(2)}`;

export default function ParentDashboard({
  parentName,
  kids,
  letters,
  notifications,
  subscription,
  certificates,
  achievements,
}: Props) {
  const router = useRouter();
  const [tab, setTab] = useState("children");
  const [activeKid, setActiveKid] = useState<number>(kids[0]?.child.id ?? 0);
  const [addons, setAddons] = useState<string[]>(subscription?.addons ?? []);
  const [linkCode, setLinkCode] = useState("");
  const [reply, setReply] = useState("");
  const [busy, setBusy] = useState(false);
  const [flash, setFlash] = useState<string | null>(null);

  const kid = kids.find((k) => k.child.id === activeKid) ?? null;
  const kidLetters = letters.filter((l) => l.childId === activeKid);

  async function act(payload: Record<string, unknown>, message?: string) {
    setBusy(true);
    const res = await fetch("/api/parent/manage", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) {
      setFlash(data.error ?? "Something went wrong.");
      return false;
    }
    if (message) setFlash(message);
    router.refresh();
    return true;
  }

  async function sendParentReply() {
    if (reply.trim().length < 2 || !kid) return;
    setBusy(true);
    const res = await fetch("/api/letters", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ asParent: true, childId: kid.child.id, body: reply }),
    });
    setBusy(false);
    if (res.ok) {
      setReply("");
      setFlash("Your letter was delivered to the mailbox as the elf ✨");
      router.refresh();
    }
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/");
    router.refresh();
  }

  const unread = notifications.filter((n) => !n.read).length;
  const shareText = "My child has a magical North Pole pen pal! 🎄 Elf Mail — letters from a real elf all year long.";
  const shareUrl = typeof window !== "undefined" ? window.location.origin : "https://elfmail.example.com";

  return (
    <main className="min-h-screen pb-16">
      <div className="sticky top-0 z-40 bg-[#0b1f3a]/85 backdrop-blur">
        <Lights bulbs={40} />
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <div>
            <p className="font-display text-lg font-bold text-amber-200">Parent Portal</p>
            <p className="text-xs text-blue-100/70">Welcome back, {parentName}</p>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/kid/register" className="rounded-full bg-red-600 px-4 py-2 text-sm font-semibold text-white">
              + Add child
            </Link>
            <button onClick={logout} className="rounded-full bg-white/12 px-4 py-2 text-sm text-white">
              Log out
            </button>
          </div>
        </div>
        <div className="mx-auto flex max-w-6xl gap-2 overflow-x-auto px-4 pb-3">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`shrink-0 rounded-full px-4 py-2 text-sm font-semibold transition ${
                tab === t.key ? "bg-emerald-600 text-white" : "bg-white/10 text-blue-50 hover:bg-white/20"
              }`}
            >
              {t.icon} {t.label}
              {t.key === "notifications" && unread > 0 && (
                <span className="ml-1 rounded-full bg-red-500 px-2 text-xs">{unread}</span>
              )}
            </button>
          ))}
        </div>
      </div>

      <div className="mx-auto max-w-6xl px-4 py-6">
        {flash && (
          <div className="mb-4 rounded-2xl border border-emerald-300/40 bg-emerald-500/15 px-4 py-3 text-emerald-100">
            {flash}
          </div>
        )}

        {kids.length > 1 && (
          <div className="mb-4 flex flex-wrap gap-2">
            {kids.map((k) => (
              <button
                key={k.child.id}
                onClick={() => setActiveKid(k.child.id)}
                className={`rounded-full px-4 py-2 text-sm font-semibold ${
                  activeKid === k.child.id ? "bg-amber-400 text-red-900" : "bg-white/12 text-white"
                }`}
              >
                {k.child.firstName} {k.elf?.emoji}
              </button>
            ))}
          </div>
        )}

        {tab === "children" && (
          <div className="grid gap-4 lg:grid-cols-3">
            <div className="space-y-4 lg:col-span-2">
              {kids.length === 0 && (
                <div className="glass rounded-3xl p-8 text-center">
                  <p className="text-4xl">🎄</p>
                  <h2 className="mt-2 font-display text-2xl font-bold text-white">Add your first child</h2>
                  <p className="mt-1 text-blue-50/80">
                    Create a profile, pick an elf, and the first letter arrives instantly.
                  </p>
                  <Link
                    href="/kid/register"
                    className="mt-4 inline-block rounded-2xl bg-red-600 px-6 py-3 font-bold text-white"
                  >
                    + Add a child
                  </Link>
                </div>
              )}
              {kids.map((k) => {
                const kCerts = certificates.filter((c) => c.childId === k.child.id);
                const kBadges = achievements.filter((a) => a.childId === k.child.id);
                const kLetters = letters.filter((l) => l.childId === k.child.id);
                return (
                  <div key={k.child.id} className="glass rounded-3xl p-6">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-display text-2xl font-bold text-amber-200">
                          {k.child.firstName}, {k.child.age}
                        </h3>
                        <p className="text-sm text-blue-50/80">
                          Pen pals with {k.elf?.name ?? "—"} {k.elf?.emoji}
                        </p>
                        <p className="mt-1 text-xs text-blue-50/65">
                          Favourite colour: {k.child.favoriteColor} · Loves: {k.child.favoriteActivity}
                          {k.child.birthday ? ` · Birthday: ${k.child.birthday}` : ""}
                        </p>
                        <p className="mt-1 text-xs text-emerald-300">Magic code: {k.child.magicCode}</p>
                      </div>
                      <span
                        className={`rounded-full px-3 py-1 text-xs font-bold ${
                          k.child.paused ? "bg-amber-400 text-red-900" : "bg-emerald-500 text-white"
                        }`}
                      >
                        {k.child.paused ? "Paused" : "Active"}
                      </span>
                    </div>
                    <div className="mt-4 grid grid-cols-4 gap-2 text-center text-xs">
                      <div className="rounded-xl bg-white/10 p-2">
                        <p className="gold-text font-display text-xl font-bold">{kLetters.length}</p>
                        <p className="text-blue-50/70">Letters</p>
                      </div>
                      <div className="rounded-xl bg-white/10 p-2">
                        <p className="gold-text font-display text-xl font-bold">{kCerts.length}</p>
                        <p className="text-blue-50/70">Certificates</p>
                      </div>
                      <div className="rounded-xl bg-white/10 p-2">
                        <p className="gold-text font-display text-xl font-bold">{kBadges.length}</p>
                        <p className="text-blue-50/70">Badges</p>
                      </div>
                      <div className="rounded-xl bg-white/10 p-2">
                        <p className="gold-text font-display text-xl font-bold capitalize">{k.child.responseMode}</p>
                        <p className="text-blue-50/70">Replies</p>
                      </div>
                    </div>
                    <button
                      onClick={() => {
                        setActiveKid(k.child.id);
                        setTab("letters");
                      }}
                      className="mt-4 w-full rounded-2xl bg-white/12 py-3 text-sm font-semibold text-white hover:bg-white/20"
                    >
                      View {k.child.firstName}&apos;s letters →
                    </button>
                  </div>
                );
              })}
            </div>
            <div className="space-y-4">
              <div className="glass rounded-3xl p-5">
                <p className="text-xs uppercase tracking-widest text-amber-200/80">Countdown to Christmas</p>
                <div className="mt-2">
                  <Countdown compact />
                </div>
              </div>
              <div className="glass rounded-3xl p-5">
                <h4 className="font-display text-lg font-bold text-amber-200">Link an existing child</h4>
                <p className="mt-1 text-xs text-blue-50/75">
                  If your child registered on their own, enter their magic code to link the profile.
                </p>
                <input
                  value={linkCode}
                  onChange={(e) => setLinkCode(e.target.value.toUpperCase())}
                  placeholder="SOFIA-SNOW123"
                  className="mt-2 w-full rounded-xl bg-white/90 px-3 py-2 text-slate-900"
                />
                <button
                  disabled={busy}
                  onClick={async () => {
                    const ok = await act({ action: "linkChild", certificateKey: linkCode }, "Child linked! 🎉");
                    if (ok) setLinkCode("");
                  }}
                  className="mt-2 w-full rounded-xl bg-emerald-700 py-2 text-sm font-bold text-white"
                >
                  Link child
                </button>
              </div>
            </div>
          </div>
        )}

        {tab === "letters" && (
          <div>
            {!kid ? (
              <p className="text-blue-50/70">Add a child to see letters.</p>
            ) : (
              <div className="grid gap-4 lg:grid-cols-2">
                <div>
                  <h3 className="font-display text-xl font-bold text-white">
                    Full transcript · {kid.child.firstName} & {kid.elf?.name}
                  </h3>
                  <div className="mt-3 max-h-[30rem] space-y-3 overflow-y-auto pr-1">
                    {kidLetters.map((l) => (
                      <div
                        key={l.id}
                        className={`rounded-2xl p-4 text-sm ${
                          l.sender === "elf" ? "bg-emerald-500/12 text-emerald-50" : "bg-red-500/12 text-red-50"
                        }`}
                      >
                        <div className="mb-1 flex justify-between text-[11px] uppercase tracking-widest opacity-70">
                          <span>{l.sender === "elf" ? kid.elf?.name : kid.child.firstName}</span>
                          <span>{new Date(l.createdAt).toLocaleString()}</span>
                        </div>
                        <p className="whitespace-pre-wrap">{l.body}</p>
                      </div>
                    ))}
                    {kidLetters.length === 0 && <p className="text-sm text-blue-50/60">No letters yet.</p>}
                  </div>
                </div>
                <div className="glass h-fit rounded-3xl p-5">
                  <h4 className="font-display text-lg font-bold text-amber-200">
                    Write as {kid.elf?.name ?? "the elf"}
                  </h4>
                  <p className="mt-1 text-xs text-blue-50/75">
                    Your words are delivered to {kid.child.firstName}&apos;s mailbox exactly as the elf.
                  </p>
                  <textarea
                    value={reply}
                    onChange={(e) => setReply(e.target.value)}
                    rows={10}
                    className="mt-3 w-full rounded-2xl bg-white/90 p-3 text-slate-900"
                    placeholder={`Dear ${kid.child.firstName}, ...`}
                  />
                  <button
                    disabled={busy}
                    onClick={sendParentReply}
                    className="mt-2 w-full rounded-2xl bg-emerald-700 py-3 font-bold text-white"
                  >
                    📮 Deliver letter
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {tab === "controls" && kid && (
          <div className="grid gap-4 lg:grid-cols-2">
            <div className="glass rounded-3xl p-6">
              <h3 className="font-display text-xl font-bold text-amber-200">Who replies to {kid.child.firstName}?</h3>
              <div className="mt-4 space-y-2">
                {[
                  { key: "ai", label: "AI Elf", desc: "The elf replies instantly, in character, with full memory." },
                  { key: "parent", label: "Parent-written", desc: "No automatic replies — you write every letter yourself." },
                  { key: "both", label: "Combination", desc: "The elf replies automatically and you can add your own letters any time." },
                ].map((o) => (
                  <button
                    key={o.key}
                    onClick={() => act({ action: "updateChild", childId: kid.child.id, responseMode: o.key }, "Reply mode updated.")}
                    className={`w-full rounded-2xl p-4 text-left transition ${
                      kid.child.responseMode === o.key ? "bg-emerald-600 text-white" : "bg-white/10 text-blue-50 hover:bg-white/20"
                    }`}
                  >
                    <p className="font-bold">{o.label}</p>
                    <p className="text-xs opacity-85">{o.desc}</p>
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-4">
              <div className="glass rounded-3xl p-6">
                <h3 className="font-display text-xl font-bold text-amber-200">Pause conversation</h3>
                <p className="mt-1 text-sm text-blue-50/80">
                  Letters stay saved, but the elf will not reply until you resume.
                </p>
                <button
                  onClick={() => act({ action: "updateChild", childId: kid.child.id, paused: !kid.child.paused }, kid.child.paused ? "Conversation resumed ✨" : "Conversation paused.")}
                  className={`mt-3 w-full rounded-2xl py-3 font-bold text-white ${kid.child.paused ? "bg-emerald-700" : "bg-amber-600"}`}
                >
                  {kid.child.paused ? "▶ Resume the magic" : "⏸ Pause conversation"}
                </button>
              </div>
              <div className="glass rounded-3xl p-6">
                <h3 className="font-display text-xl font-bold text-amber-200">Premium certificates</h3>
                <div className="mt-3 space-y-2">
                  {CERTIFICATE_CATALOG.filter((c) => c.premium).map((c) => {
                    const owned = certificates.some((x) => x.childId === kid.child.id && x.key === c.key);
                    return (
                      <div key={c.key} className="flex items-center justify-between rounded-2xl bg-white/10 p-3">
                        <div>
                          <p className="text-sm font-bold text-white">{c.title}</p>
                          <p className="text-xs text-blue-50/70">{c.blurb}</p>
                        </div>
                        <button
                          disabled={owned || busy}
                          onClick={() => act({ action: "unlockPremiumCertificate", childId: kid.child.id, certificateKey: c.key }, `${c.title} unlocked!`)}
                          className="rounded-full bg-amber-400 px-4 py-2 text-xs font-bold text-red-900 disabled:opacity-50"
                        >
                          {owned ? "Unlocked" : "Unlock $4.99"}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}

        {tab === "plans" && (
          <div>
            <div className="grid gap-4 lg:grid-cols-3">
              {PLANS.map((p) => {
                const active = subscription?.plan === p.key;
                return (
                  <div
                    key={p.key}
                    className={`rounded-3xl border p-6 ${
                      p.highlight ? "border-amber-300 bg-amber-300/10" : "border-white/15 bg-white/6"
                    }`}
                  >
                    {p.highlight && (
                      <span className="rounded-full bg-amber-400 px-3 py-1 text-xs font-bold text-red-900">
                        Most magical
                      </span>
                    )}
                    <h3 className="mt-2 font-display text-2xl font-bold text-amber-200">{p.name}</h3>
                    <p className="mt-1 font-display text-3xl font-bold text-white">
                      {money(p.priceCents)} <span className="text-sm font-normal text-blue-50/70">{p.cadence}</span>
                    </p>
                    <ul className="mt-3 space-y-1 text-sm text-blue-50/85">
                      {p.features.map((f) => (
                        <li key={f}>✓ {f}</li>
                      ))}
                    </ul>
                    <button
                      disabled={busy}
                      onClick={() => act({ action: "subscribe", plan: p.key, addons }, `${p.name} activated! 🎉`)}
                      className={`mt-4 w-full rounded-2xl py-3 font-bold text-white ${active ? "bg-emerald-700" : "bg-red-600"}`}
                    >
                      {active ? "Current plan — update add-ons" : `Choose ${p.name}`}
                    </button>
                  </div>
                );
              })}
            </div>

            <h3 className="mt-8 font-display text-xl font-bold text-white">Optional add-ons</h3>
            <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {ADDONS.map((a) => {
                const on = addons.includes(a.key);
                return (
                  <button
                    key={a.key}
                    onClick={() => setAddons(on ? addons.filter((x) => x !== a.key) : [...addons, a.key])}
                    className={`rounded-2xl p-4 text-left transition ${
                      on ? "bg-emerald-600 text-white ring-2 ring-amber-300" : "bg-white/10 text-blue-50 hover:bg-white/20"
                    }`}
                  >
                    <p className="font-bold">{a.name}</p>
                    <p className="text-sm opacity-85">{money(a.priceCents)}</p>
                  </button>
                );
              })}
            </div>
            <p className="mt-3 text-xs text-blue-50/60">
              Add-ons are applied when you choose or update a plan above. Payments are processed securely — this
              demo records the order without charging a card.
            </p>
            {subscription && (
              <div className="glass mt-6 rounded-3xl p-5">
                <p className="text-sm text-blue-50/85">
                  Active plan: <b className="text-amber-200">{subscription.plan}</b> · Total{" "}
                  {money(subscription.priceCents)} · Started{" "}
                  {new Date(subscription.startedAt).toLocaleDateString()}
                </p>
              </div>
            )}
          </div>
        )}

        {tab === "notifications" && (
          <div>
            <div className="mb-3 flex items-center justify-between">
              <h3 className="font-display text-xl font-bold text-white">Notifications</h3>
              <button
                onClick={() => act({ action: "readAllNotifications" }, "All caught up ✨")}
                className="rounded-full bg-white/12 px-4 py-2 text-sm text-white"
              >
                Mark all read
              </button>
            </div>
            <div className="space-y-2">
              {notifications.map((n) => (
                <div
                  key={n.id}
                  className={`rounded-2xl p-4 ${n.read ? "bg-white/6" : "bg-amber-300/15 ring-1 ring-amber-300/40"}`}
                >
                  <div className="flex justify-between">
                    <p className="font-bold text-amber-200">{n.title}</p>
                    <span className="text-xs text-blue-50/60">{new Date(n.createdAt).toLocaleString()}</span>
                  </div>
                  <p className="text-sm text-blue-50/85">{n.body}</p>
                </div>
              ))}
              {notifications.length === 0 && <p className="text-sm text-blue-50/60">Nothing yet.</p>}
            </div>
            <p className="mt-4 text-xs text-blue-50/60">
              Email + push notifications are sent for new letters, certificates, videos and countdown events.
            </p>
          </div>
        )}

        {tab === "share" && (
          <div className="grid gap-4 lg:grid-cols-2">
            <div className="glass rounded-3xl p-6">
              <h3 className="font-display text-xl font-bold text-amber-200">Share the magic 📣</h3>
              <p className="mt-2 text-sm text-blue-50/85">{shareText}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                <a
                  className="rounded-full bg-[#1877f2] px-4 py-2 text-sm font-bold text-white"
                  href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  Share on Facebook
                </a>
                <a
                  className="rounded-full bg-black px-4 py-2 text-sm font-bold text-white"
                  href={`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  Share on X
                </a>
                <button
                  onClick={() => {
                    void navigator.clipboard.writeText(`${shareText} ${shareUrl}`);
                    setFlash("Copied to clipboard!");
                  }}
                  className="rounded-full bg-white/15 px-4 py-2 text-sm font-bold text-white"
                >
                  Copy message
                </button>
              </div>
            </div>
            <div className="overflow-hidden rounded-3xl">
              <div className="relative flex h-64 flex-col items-center justify-center bg-gradient-to-br from-red-700 via-red-600 to-emerald-800 p-6 text-center">
                <p className="text-4xl">🎄🧝🎅</p>
                <p className="mt-2 font-display text-2xl font-bold text-white">
                  {kids[0]?.child.firstName ?? "My child"} has a North Pole pen pal!
                </p>
                <p className="mt-1 font-hand text-lg text-amber-200">Letters from a real elf, all year long ✨</p>
                <p className="absolute bottom-3 text-xs uppercase tracking-widest text-white/80">elfmail.app</p>
              </div>
              <p className="bg-white/10 px-4 py-3 text-xs text-blue-50/70">
                Festive share graphic — screenshot or save to post on social media.
              </p>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
