import { redirect } from "next/navigation";
import type { Metadata } from "next";
import { db } from "@/db";
import { children, elves, letters, notifications, subscriptions, certificates, achievements } from "@/db/schema";
import { eq, desc, and } from "drizzle-orm";
import { getCurrentParent } from "@/lib/auth";
import ParentDashboard from "./ParentDashboard";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Parent Portal",
  description: "Manage children, monitor every letter, choose reply modes and handle your subscription.",
  robots: { index: false, follow: false },
};

export default async function Page() {
  const parent = await getCurrentParent();
  if (!parent) redirect("/parent/login");

  const kidRows = await db
    .select({ child: children, elf: elves })
    .from(children)
    .leftJoin(elves, eq(children.elfId, elves.id))
    .where(eq(children.parentId, parent.id))
    .orderBy(children.id);

  const kidIds = kidRows.map((k) => k.child.id);

  const [allLetters, notes, subs, certs, badges] = await Promise.all([
    kidIds.length
      ? db.select().from(letters).orderBy(desc(letters.createdAt)).limit(400)
      : Promise.resolve([]),
    db.select().from(notifications).where(eq(notifications.parentId, parent.id)).orderBy(desc(notifications.createdAt)).limit(50),
    db
      .select()
      .from(subscriptions)
      .where(and(eq(subscriptions.parentId, parent.id), eq(subscriptions.status, "active")))
      .limit(1),
    kidIds.length ? db.select().from(certificates) : Promise.resolve([]),
    kidIds.length ? db.select().from(achievements) : Promise.resolve([]),
  ]);

  const scopedLetters = allLetters.filter((l) => kidIds.includes(l.childId));
  const scopedCerts = certs.filter((c) => kidIds.includes(c.childId));
  const scopedBadges = badges.filter((b) => kidIds.includes(b.childId));

  return (
    <ParentDashboard
      parentName={parent.name}
      kids={kidRows}
      letters={scopedLetters}
      notifications={notes}
      subscription={subs[0] ?? null}
      certificates={scopedCerts}
      achievements={scopedBadges}
    />
  );
}
