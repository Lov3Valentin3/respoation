import type { Metadata } from "next";
import ParentAuthForm from "@/components/ParentAuthForm";

export const metadata: Metadata = {
  title: "Parent Login",
  description: "Sign in to your Elf Mail parent portal to manage children, letters and subscriptions.",
  alternates: { canonical: "/parent/login" },
};

export default function Page() {
  return <ParentAuthForm mode="login" />;
}
