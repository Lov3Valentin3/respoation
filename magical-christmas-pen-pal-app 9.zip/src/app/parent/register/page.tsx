import type { Metadata } from "next";
import ParentAuthForm from "@/components/ParentAuthForm";

export const metadata: Metadata = {
  title: "Parent Register",
  description:
    "Create a free Elf Mail family account: full letter transparency, multiple children, parent-written or AI elf replies, and flexible plans.",
  alternates: { canonical: "/parent/register" },
};

export default function Page() {
  return <ParentAuthForm mode="register" />;
}
