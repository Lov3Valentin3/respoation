import type { Metadata } from "next";
import Link from "next/link";
import Lights from "@/components/Lights";
import { PLANS, ADDONS } from "@/lib/elf-data";

export const metadata: Metadata = {
  title: "Plans & Pricing — Elf Pen Pal Memberships",
  description:
    "Monthly, annual and lifetime North Pole memberships. Unlimited elf letters, printable Santa certificates, personalised videos, printed letters mailed home and gift box upgrades.",
  alternates: { canonical: "/pricing" },
};

const money = (cents: number) => `$${(cents / 100).toFixed(2)}`;

export default function PricingPage() {
  const ld = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: "Elf Mail Membership",
    description: "A magical Christmas pen pal subscription for children ages 3-12.",
    offers: PLANS.map((p) => ({
      "@type": "Offer",
      name: p.name,
      price: (p.priceCents / 100).toFixed(2),
      priceCurrency: "USD",
      availability: "https://schema.org/InStock",
    })),
  };

  return (
    <main className="min-h-screen">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(ld) }} />
      <Lights bulbs={40} />
      <div className="mx-auto max-w-6xl px-4 py-10">
        <Link href="/" className="text-sm text-amber-200 hover:underline">← Back home</Link>
        <h1 className="mt-3 text-center font-display text-4xl font-bold text-white sm:text-5xl">
          Choose your <span className="gold-text">North Pole membership</span>
        </h1>
        <p className="mx-auto mt-3 max-w-2xl text-center text-blue-50/85">
          Start free — your child&apos;s first elf letter is always on us. Upgrade any time for unlimited letters,
          premium certificates and personalised videos.
        </p>

        <div className="mt-10 grid gap-5 lg:grid-cols-3">
          {PLANS.map((p) => (
            <div
              key={p.key}
              className={`rounded-3xl border p-7 ${
                p.highlight ? "border-amber-300 bg-amber-300/10 shadow-2xl" : "border-white/15 bg-white/6"
              }`}
            >
              {p.highlight && (
                <span className="rounded-full bg-amber-400 px-3 py-1 text-xs font-bold text-red-900">Most magical</span>
              )}
              <h2 className="mt-2 font-display text-2xl font-bold text-amber-200">{p.name}</h2>
              <p className="mt-2 font-display text-4xl font-bold text-white">
                {money(p.priceCents)}
                <span className="ml-1 text-sm font-normal text-blue-50/70">{p.cadence}</span>
              </p>
              <ul className="mt-4 space-y-2 text-sm text-blue-50/90">
                {p.features.map((f) => (
                  <li key={f}>✓ {f}</li>
                ))}
              </ul>
              <Link
                href="/parent/register"
                className="mt-6 block rounded-2xl bg-red-600 py-3 text-center font-bold text-white hover:bg-red-500"
              >
                Get started
              </Link>
            </div>
          ))}
        </div>

        <h2 className="mt-14 text-center font-display text-3xl font-bold text-white">Magical add-ons</h2>
        <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {ADDONS.map((a) => (
            <div key={a.key} className="glass rounded-2xl p-5">
              <p className="font-bold text-amber-200">{a.name}</p>
              <p className="mt-1 text-2xl font-bold text-white">{money(a.priceCents)}</p>
            </div>
          ))}
        </div>

        <div className="glass mt-12 rounded-3xl p-8 text-center">
          <h2 className="font-display text-2xl font-bold text-white">Safe, private and parent-controlled</h2>
          <p className="mx-auto mt-2 max-w-2xl text-blue-50/85">
            Parents see every letter, choose whether replies come from the AI elf or from you, and can pause the
            conversation at any moment. No ads, no chat with strangers, no data sold. Ever.
          </p>
          <Link
            href="/parent/register"
            className="mt-5 inline-block rounded-2xl bg-gradient-to-b from-emerald-500 to-emerald-700 px-8 py-4 text-lg font-bold text-white shadow-xl ring-2 ring-white/25"
          >
            Create a free family account
          </Link>
        </div>
      </div>
    </main>
  );
}
