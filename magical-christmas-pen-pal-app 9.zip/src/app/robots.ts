import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/api/", "/kid/dashboard", "/parent/dashboard"] }],
    sitemap: "https://elfmail.example.com/sitemap.xml",
  };
}
