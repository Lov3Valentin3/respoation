import type { MetadataRoute } from "next";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = "https://elfmail.example.com";
  const now = new Date();
  return [
    { url: `${base}/`, lastModified: now, changeFrequency: "daily", priority: 1 },
    { url: `${base}/elves`, lastModified: now, changeFrequency: "weekly", priority: 0.9 },
    { url: `${base}/pricing`, lastModified: now, changeFrequency: "weekly", priority: 0.8 },
    { url: `${base}/kid/register`, lastModified: now, changeFrequency: "monthly", priority: 0.7 },
    { url: `${base}/parent/register`, lastModified: now, changeFrequency: "monthly", priority: 0.7 },
  ];
}
