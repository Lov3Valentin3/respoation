"use client";

import { useEffect, useState } from "react";

function nextChristmas() {
  const now = new Date();
  const year = now.getMonth() === 11 && now.getDate() > 25 ? now.getFullYear() + 1 : now.getFullYear();
  return new Date(year, 11, 25, 0, 0, 0);
}

export default function Countdown({ compact = false }: { compact?: boolean }) {
  const [parts, setParts] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const tick = () => {
      const diff = Math.max(0, nextChristmas().getTime() - Date.now());
      setParts({
        days: Math.floor(diff / 86400000),
        hours: Math.floor((diff / 3600000) % 24),
        minutes: Math.floor((diff / 60000) % 60),
        seconds: Math.floor((diff / 1000) % 60),
      });
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);

  const cells = [
    { label: "Days", value: parts.days },
    { label: "Hours", value: parts.hours },
    { label: "Minutes", value: parts.minutes },
    { label: "Seconds", value: parts.seconds },
  ];

  return (
    <div className={`grid grid-cols-4 gap-2 ${compact ? "max-w-xs" : "max-w-md"}`}>
      {cells.map((c) => (
        <div
          key={c.label}
          className="rounded-2xl border border-amber-300/40 bg-gradient-to-b from-red-700/70 to-red-900/70 px-1 py-2 text-center shadow-lg"
        >
          <div className={`gold-text font-display font-bold ${compact ? "text-xl" : "text-3xl"}`}>
            {String(c.value).padStart(2, "0")}
          </div>
          <div className="text-[10px] uppercase tracking-widest text-amber-100/80">{c.label}</div>
        </div>
      ))}
    </div>
  );
}
