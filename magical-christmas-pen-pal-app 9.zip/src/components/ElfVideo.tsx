"use client";

import { useEffect, useState } from "react";

type Scene = {
  bg: string;
  props: string[];
  captions: string[];
};

const SCENES: Record<string, Scene> = {
  "workshop-door": {
    bg: "linear-gradient(180deg,#1b3b6f,#0d2b23)",
    props: ["🚪", "🧝", "🔔", "❄️"],
    captions: ["Hi {name}! It's me!", "*waves both arms wildly*", "Come in, come in — it's freezing!"],
  },
  workshop: {
    bg: "linear-gradient(180deg,#5a2222,#2a1010)",
    props: ["🔨", "🧸", "🚂", "🪀", "🎁"],
    captions: ["Welcome to Santa's workshop, {name}!", "3,000 toys made before lunch!", "That teddy bear? Might be yours..."],
  },
  tree: {
    bg: "linear-gradient(180deg,#0b3d2e,#041f17)",
    props: ["🎄", "✨", "🔴", "🟡", "⭐"],
    captions: ["This tree is 90 feet tall, {name}!", "Tinsel is hanging the star...", "Three... two... one... LIGHTS!"],
  },
  reindeer: {
    bg: "linear-gradient(180deg,#2d4a6b,#122536)",
    props: ["🦌", "🥕", "🌾", "❄️"],
    captions: ["Breakfast time in the barn!", "Comet says hello, {name}.", "Careful — Dasher licks!"],
  },
  snow: {
    bg: "linear-gradient(180deg,#20456e,#0b1f3a)",
    props: ["❄️", "🌨️", "⛄", "🌲"],
    captions: ["Live from the North Pole...", "It's so quiet you can hear the snow, {name}.", "Frost drew every one of these flakes."],
  },
  office: {
    bg: "linear-gradient(180deg,#3b1f0b,#1b0f06)",
    props: ["📕", "🕯️", "🎅", "🪑"],
    captions: ["Shhh! We're in Santa's office...", "The Nice List is glowing!", "I see your name, {name}! 🤫"],
  },
  sleigh: {
    bg: "linear-gradient(180deg,#101a3a,#05070f)",
    props: ["🛷", "🎁", "🌟", "🦌"],
    captions: ["Loading the sleigh, {name}!", "Your present is in the red sack.", "Christmas Eve, here we come!"],
  },
  shoutout: {
    bg: "linear-gradient(180deg,#6b1b3a,#2a0a17)",
    props: ["📣", "🧝", "✨", "🎉"],
    captions: ["Ready? Here goes...", "{name}!!!", "You are officially North Pole famous!"],
  },
};

export default function ElfVideo({
  scene,
  title,
  name,
  elfEmoji,
}: {
  scene: string;
  title: string;
  name: string;
  elfEmoji: string;
}) {
  const data = SCENES[scene] ?? SCENES.snow;
  const [playing, setPlaying] = useState(false);
  const [frame, setFrame] = useState(0);

  useEffect(() => {
    if (!playing) return;
    const id = setInterval(() => {
      setFrame((f) => {
        if (f + 1 >= data.captions.length) {
          clearInterval(id);
          return f;
        }
        return f + 1;
      });
    }, 2600);
    return () => clearInterval(id);
  }, [playing, data.captions.length]);

  return (
    <div className="overflow-hidden rounded-3xl border border-white/15">
      <div className="relative h-52 w-full" style={{ background: data.bg }}>
        {data.props.map((p, i) => (
          <span
            key={i}
            className="absolute select-none"
            style={{
              left: `${8 + i * 20}%`,
              top: `${20 + ((i * 27) % 45)}%`,
              fontSize: `${28 + (i % 3) * 12}px`,
              animation: `float-soft ${3 + i * 0.6}s ease-in-out infinite`,
              animationDelay: `${i * 0.3}s`,
            }}
          >
            {p}
          </span>
        ))}
        <span
          className="absolute bottom-4 right-6 text-5xl"
          style={{ animation: "float-soft 2.4s ease-in-out infinite" }}
        >
          {elfEmoji}
        </span>

        {!playing ? (
          <button
            onClick={() => {
              setPlaying(true);
              setFrame(0);
            }}
            className="absolute inset-0 flex items-center justify-center bg-black/40 text-white transition hover:bg-black/25"
          >
            <span className="flex h-16 w-16 items-center justify-center rounded-full bg-red-600 text-2xl shadow-xl ring-4 ring-white/40">
              ▶
            </span>
          </button>
        ) : (
          <div className="absolute inset-x-0 bottom-0 bg-black/55 px-4 py-3 text-center">
            <p className="font-hand text-lg text-white">
              {data.captions[frame].replace("{name}", name)}
            </p>
          </div>
        )}
      </div>
      <div className="flex items-center justify-between bg-white/10 px-4 py-3">
        <p className="font-display text-sm font-bold text-amber-200">{title}</p>
        {playing && (
          <button
            onClick={() => {
              setPlaying(false);
              setFrame(0);
            }}
            className="rounded-full bg-white/15 px-3 py-1 text-xs text-white"
          >
            Replay
          </button>
        )}
      </div>
    </div>
  );
}
