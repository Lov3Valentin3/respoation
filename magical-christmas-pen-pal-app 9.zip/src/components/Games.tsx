"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { GAME_CATALOG } from "@/lib/elf-data";

type Props = { childName: string; elfEmoji: string; earned: string[] };

const CARD_EMOJI = ["🎁", "🔔", "⭐", "🍬", "🦌", "⛄"];

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/* ---------------- Memory ---------------- */
function MemoryGame({ onWin }: { onWin: (score: number) => void }) {
  const [deck, setDeck] = useState<string[]>(() => shuffle([...CARD_EMOJI, ...CARD_EMOJI]));
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matched, setMatched] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);

  useEffect(() => {
    if (flipped.length === 2) {
      const [a, b] = flipped;
      if (deck[a] === deck[b]) setMatched((m) => [...m, a, b]);
      const t = setTimeout(() => setFlipped([]), 700);
      return () => clearTimeout(t);
    }
  }, [flipped, deck]);

  useEffect(() => {
    if (matched.length === deck.length) onWin(Math.max(10, 100 - moves * 4));
  }, [matched, deck.length, moves, onWin]);

  return (
    <div>
      <p className="mb-3 text-sm text-blue-50/80">Moves: {moves}</p>
      <div className="grid grid-cols-4 gap-2 sm:gap-3">
        {deck.map((emoji, i) => {
          const open = flipped.includes(i) || matched.includes(i);
          return (
            <button
              key={i}
              onClick={() => {
                if (open || flipped.length === 2) return;
                setMoves((m) => m + 1);
                setFlipped((f) => [...f, i]);
              }}
              className={`flex aspect-square items-center justify-center rounded-2xl text-3xl transition ${
                open ? "bg-amber-200 text-red-800" : "btn-candy text-transparent"
              }`}
            >
              {open ? emoji : "?"}
            </button>
          );
        })}
      </div>
      {matched.length === deck.length && (
        <p className="mt-4 text-center font-display text-xl text-amber-200">🎉 All matched! Badge earned!</p>
      )}
      <button
        onClick={() => {
          setDeck(shuffle([...CARD_EMOJI, ...CARD_EMOJI]));
          setFlipped([]);
          setMatched([]);
          setMoves(0);
        }}
        className="mt-4 rounded-full bg-white/15 px-4 py-2 text-sm text-white"
      >
        Play again
      </button>
    </div>
  );
}

/* ---------------- Match the Presents ---------------- */
const PRESENTS = ["🎁", "🎀", "📦", "🧸", "🪀", "🎠", "🚂", "🪁"];
function MatchPresents({ onWin }: { onWin: (score: number) => void }) {
  const [round, setRound] = useState(0);
  const [grid, setGrid] = useState<string[]>([]);
  const [picked, setPicked] = useState<number[]>([]);
  const [msg, setMsg] = useState("Find the two presents that match!");

  const build = useCallback(() => {
    const pool = shuffle(PRESENTS).slice(0, 7);
    const dup = pool[0];
    setGrid(shuffle([...pool, dup]));
    setPicked([]);
  }, []);

  useEffect(() => build(), [build]);

  function tap(i: number) {
    if (picked.includes(i)) return;
    const next = [...picked, i];
    if (next.length === 2) {
      if (grid[next[0]] === grid[next[1]]) {
        const r = round + 1;
        setRound(r);
        setMsg("Perfect match! 🎉");
        if (r >= 3) onWin(r * 30);
        setTimeout(build, 600);
      } else {
        setMsg("Not quite — try again!");
        setTimeout(() => setPicked([]), 500);
      }
      setPicked(next);
    } else {
      setPicked(next);
    }
  }

  return (
    <div>
      <p className="mb-3 text-sm text-blue-50/80">Round {Math.min(round + 1, 3)} of 3 · {msg}</p>
      <div className="grid grid-cols-4 gap-3">
        {grid.map((g, i) => (
          <button
            key={i}
            onClick={() => tap(i)}
            className={`flex aspect-square items-center justify-center rounded-2xl text-4xl transition ${
              picked.includes(i) ? "bg-amber-300 ring-4 ring-amber-200" : "bg-white/12 hover:bg-white/25"
            }`}
          >
            {g}
          </button>
        ))}
      </div>
      {round >= 3 && <p className="mt-4 text-center font-display text-xl text-amber-200">🏆 Gift Guru badge earned!</p>}
    </div>
  );
}

/* ---------------- Find the Elf ---------------- */
const CROWD = ["🎅", "⛄", "🦌", "🐧", "🧦", "🕯️", "🍭", "🎄"];
function FindElf({ elfEmoji, onWin }: { elfEmoji: string; onWin: (score: number) => void }) {
  const [found, setFound] = useState(0);
  const [cells, setCells] = useState<string[]>([]);
  const [target, setTarget] = useState(0);

  const build = useCallback(() => {
    const size = 36;
    const arr = Array.from({ length: size }, () => CROWD[Math.floor(Math.random() * CROWD.length)]);
    const idx = Math.floor(Math.random() * size);
    arr[idx] = "🧝";
    setCells(arr);
    setTarget(idx);
  }, []);

  useEffect(() => build(), [build]);

  return (
    <div>
      <p className="mb-3 text-sm text-blue-50/80">
        Find the hidden elf 🧝 — found {found} of 3 {elfEmoji}
      </p>
      <div className="grid grid-cols-6 gap-1 rounded-2xl bg-white/8 p-2">
        {cells.map((c, i) => (
          <button
            key={i}
            onClick={() => {
              if (i === target) {
                const f = found + 1;
                setFound(f);
                if (f >= 3) onWin(f * 33);
                else build();
              }
            }}
            className="flex aspect-square items-center justify-center rounded-lg text-2xl hover:bg-white/20"
          >
            {c}
          </button>
        ))}
      </div>
      {found >= 3 && <p className="mt-4 text-center font-display text-xl text-amber-200">🔍 Elf Spotter badge earned!</p>}
    </div>
  );
}

/* ---------------- Trivia ---------------- */
const TRIVIA = [
  { q: "How many reindeer pull Santa's sleigh (with Rudolph)?", a: ["9", "5", "12"], correct: 0 },
  { q: "What do elves leave out for Santa to eat?", a: ["Pizza", "Cookies and milk", "Soup"], correct: 1 },
  { q: "What colour is Rudolph's nose?", a: ["Green", "Blue", "Red"], correct: 2 },
  { q: "Where do the elves work?", a: ["Santa's workshop", "The moon", "A submarine"], correct: 0 },
  { q: "What do you hang by the fireplace?", a: ["Umbrellas", "Stockings", "Bicycles"], correct: 1 },
];
function Trivia({ onWin }: { onWin: (score: number) => void }) {
  const [i, setI] = useState(0);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);

  if (done) {
    return (
      <div className="text-center">
        <p className="font-display text-2xl text-amber-200">You scored {score} / {TRIVIA.length}!</p>
        <button
          onClick={() => { setI(0); setScore(0); setDone(false); }}
          className="mt-4 rounded-full bg-white/15 px-4 py-2 text-sm text-white"
        >
          Play again
        </button>
      </div>
    );
  }

  const q = TRIVIA[i];
  return (
    <div>
      <p className="mb-2 text-sm text-blue-50/70">Question {i + 1} of {TRIVIA.length}</p>
      <h4 className="font-display text-xl text-white">{q.q}</h4>
      <div className="mt-4 space-y-2">
        {q.a.map((option, oi) => (
          <button
            key={option}
            onClick={() => {
              const s = oi === q.correct ? score + 1 : score;
              setScore(s);
              if (i + 1 >= TRIVIA.length) {
                setDone(true);
                if (s >= 3) onWin(s * 20);
              } else setI(i + 1);
            }}
            className="w-full rounded-2xl bg-white/12 px-4 py-3 text-left font-semibold text-white hover:bg-emerald-600"
          >
            {option}
          </button>
        ))}
      </div>
    </div>
  );
}

/* ---------------- Word Search ---------------- */
const WORDS = ["SNOW", "ELF", "SLEIGH", "STAR", "GIFT"];
function WordSearch({ onWin }: { onWin: (score: number) => void }) {
  const size = 8;
  const board = useMemo(() => {
    const grid: string[][] = Array.from({ length: size }, () =>
      Array.from({ length: size }, () => String.fromCharCode(65 + Math.floor(Math.random() * 26))),
    );
    const placed: { word: string; row: number; col: number }[] = [];
    WORDS.forEach((w, idx) => {
      const row = idx;
      const col = Math.floor(Math.random() * (size - w.length));
      for (let k = 0; k < w.length; k++) grid[row][col + k] = w[k];
      placed.push({ word: w, row, col });
    });
    return { grid, placed };
  }, []);
  const [found, setFound] = useState<string[]>([]);
  const [start, setStart] = useState<[number, number] | null>(null);

  function tap(r: number, c: number) {
    if (!start) return setStart([r, c]);
    const [sr, sc] = start;
    setStart(null);
    if (sr !== r) return;
    const from = Math.min(sc, c);
    const to = Math.max(sc, c);
    const text = board.grid[r].slice(from, to + 1).join("");
    const hit = board.placed.find((p) => p.word === text && p.row === r && p.col === from);
    if (hit && !found.includes(hit.word)) {
      const next = [...found, hit.word];
      setFound(next);
      if (next.length === WORDS.length) onWin(100);
    }
  }

  return (
    <div>
      <p className="mb-2 text-sm text-blue-50/80">Tap the first and last letter of each word.</p>
      <div className="mb-3 flex flex-wrap gap-2">
        {WORDS.map((w) => (
          <span
            key={w}
            className={`rounded-full px-3 py-1 text-xs font-bold ${
              found.includes(w) ? "bg-emerald-500 text-white line-through" : "bg-white/15 text-amber-100"
            }`}
          >
            {w}
          </span>
        ))}
      </div>
      <div className="inline-grid grid-cols-8 gap-1 rounded-2xl bg-white/8 p-2">
        {board.grid.map((row, r) =>
          row.map((ch, c) => {
            const isFound = board.placed.some(
              (p) => found.includes(p.word) && p.row === r && c >= p.col && c < p.col + p.word.length,
            );
            const selected = start?.[0] === r && start?.[1] === c;
            return (
              <button
                key={`${r}-${c}`}
                onClick={() => tap(r, c)}
                className={`h-8 w-8 rounded text-sm font-bold transition ${
                  isFound ? "bg-emerald-500 text-white" : selected ? "bg-amber-300 text-red-900" : "bg-white/15 text-white hover:bg-white/30"
                }`}
              >
                {ch}
              </button>
            );
          }),
        )}
      </div>
      {found.length === WORDS.length && <p className="mt-3 font-display text-xl text-amber-200">🔤 Word Wizard badge earned!</p>}
    </div>
  );
}

/* ---------------- Elf Maze ---------------- */
const MAZE = [
  "S.#.......",
  ".##.#####.",
  "....#...#.",
  "###.#.#.#.",
  "....#.#...",
  ".####.###.",
  "......#...",
  ".#####.##.",
  ".....#...E",
  "####.#.###",
];
function Maze({ onWin }: { onWin: (score: number) => void }) {
  const [pos, setPos] = useState({ r: 0, c: 0 });
  const [won, setWon] = useState(false);
  const [steps, setSteps] = useState(0);

  const move = useCallback(
    (dr: number, dc: number) => {
      setPos((p) => {
        const r = p.r + dr;
        const c = p.c + dc;
        if (r < 0 || c < 0 || r >= MAZE.length || c >= MAZE[0].length) return p;
        if (MAZE[r][c] === "#") return p;
        setSteps((s) => s + 1);
        if (MAZE[r][c] === "E") {
          setWon(true);
          onWin(100);
        }
        return { r, c };
      });
    },
    [onWin],
  );

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "ArrowUp") move(-1, 0);
      if (e.key === "ArrowDown") move(1, 0);
      if (e.key === "ArrowLeft") move(0, -1);
      if (e.key === "ArrowRight") move(0, 1);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [move]);

  return (
    <div className="flex flex-col items-center">
      <p className="mb-2 text-sm text-blue-50/80">Guide your elf to the workshop 🏠 · steps: {steps}</p>
      <div className="inline-grid grid-cols-10 gap-[2px] rounded-2xl bg-white/8 p-2">
        {MAZE.flatMap((row, r) =>
          row.split("").map((cell, c) => (
            <div
              key={`${r}-${c}`}
              className={`flex h-7 w-7 items-center justify-center rounded text-sm ${
                cell === "#" ? "bg-emerald-900" : "bg-white/25"
              }`}
            >
              {pos.r === r && pos.c === c ? "🧝" : cell === "E" ? "🏠" : ""}
            </div>
          )),
        )}
      </div>
      <div className="mt-4 grid w-40 grid-cols-3 gap-2">
        <span />
        <button onClick={() => move(-1, 0)} className="rounded-xl bg-white/15 py-2 text-white">▲</button>
        <span />
        <button onClick={() => move(0, -1)} className="rounded-xl bg-white/15 py-2 text-white">◀</button>
        <button onClick={() => move(1, 0)} className="rounded-xl bg-white/15 py-2 text-white">▼</button>
        <button onClick={() => move(0, 1)} className="rounded-xl bg-white/15 py-2 text-white">▶</button>
      </div>
      {won && <p className="mt-3 font-display text-xl text-amber-200">🌀 Maze Runner badge earned!</p>}
    </div>
  );
}

/* ---------------- Coloring ---------------- */
const PALETTE = ["#e53935", "#2e7d32", "#f2c14e", "#1e88e5", "#8e24aa", "#ffffff", "#795548", "#ec407a"];
function Coloring({ onWin }: { onWin: (score: number) => void }) {
  const [color, setColor] = useState(PALETTE[0]);
  const [fills, setFills] = useState<Record<string, string>>({});
  const regions = ["tree1", "tree2", "tree3", "trunk", "star", "ball1", "ball2", "ball3"];

  function paint(id: string) {
    const next = { ...fills, [id]: color };
    setFills(next);
    if (Object.keys(next).length >= regions.length) onWin(100);
  }

  const fill = (id: string, fallback: string) => fills[id] ?? fallback;

  return (
    <div className="flex flex-col items-center">
      <div className="mb-3 flex flex-wrap justify-center gap-2">
        {PALETTE.map((c) => (
          <button
            key={c}
            onClick={() => setColor(c)}
            className={`h-9 w-9 rounded-full border-2 ${color === c ? "scale-110 border-amber-300 ring-4 ring-amber-300/40" : "border-white/40"}`}
            style={{ background: c }}
          />
        ))}
      </div>
      <svg viewBox="0 0 200 240" className="h-72 w-56 rounded-2xl bg-white">
        <polygon points="100,10 130,70 70,70" fill={fill("tree1", "#eee")} stroke="#333" strokeWidth="2" onClick={() => paint("tree1")} />
        <polygon points="100,55 145,125 55,125" fill={fill("tree2", "#eee")} stroke="#333" strokeWidth="2" onClick={() => paint("tree2")} />
        <polygon points="100,105 165,190 35,190" fill={fill("tree3", "#eee")} stroke="#333" strokeWidth="2" onClick={() => paint("tree3")} />
        <rect x="85" y="190" width="30" height="40" fill={fill("trunk", "#eee")} stroke="#333" strokeWidth="2" onClick={() => paint("trunk")} />
        <polygon points="100,0 106,14 121,14 109,23 114,38 100,29 86,38 91,23 79,14 94,14" fill={fill("star", "#eee")} stroke="#333" strokeWidth="2" onClick={() => paint("star")} />
        <circle cx="100" cy="95" r="9" fill={fill("ball1", "#eee")} stroke="#333" strokeWidth="2" onClick={() => paint("ball1")} />
        <circle cx="80" cy="150" r="9" fill={fill("ball2", "#eee")} stroke="#333" strokeWidth="2" onClick={() => paint("ball2")} />
        <circle cx="125" cy="165" r="9" fill={fill("ball3", "#eee")} stroke="#333" strokeWidth="2" onClick={() => paint("ball3")} />
      </svg>
      <p className="mt-2 text-sm text-blue-50/80">Tap a shape to colour it in!</p>
    </div>
  );
}

/* ---------------- Snowball sliding puzzle ---------------- */
function SnowballPuzzle({ onWin }: { onWin: (score: number) => void }) {
  const solved = [1, 2, 3, 4, 5, 6, 7, 8, 0];
  const [tiles, setTiles] = useState<number[]>(() => {
    let arr = [...solved];
    for (let i = 0; i < 60; i++) {
      const empty = arr.indexOf(0);
      const moves = [empty - 3, empty + 3, empty % 3 === 0 ? -1 : empty - 1, empty % 3 === 2 ? -1 : empty + 1].filter(
        (m) => m >= 0 && m < 9,
      );
      const target = moves[Math.floor(Math.random() * moves.length)];
      arr = arr.map((v, idx) => (idx === empty ? arr[target] : idx === target ? 0 : v));
    }
    return arr;
  });
  const won = tiles.every((v, i) => v === solved[i]);

  useEffect(() => {
    if (won) onWin(100);
  }, [won, onWin]);

  function slide(i: number) {
    const empty = tiles.indexOf(0);
    const sameRow = Math.floor(i / 3) === Math.floor(empty / 3);
    const ok = (Math.abs(i - empty) === 1 && sameRow) || Math.abs(i - empty) === 3;
    if (!ok) return;
    const next = [...tiles];
    next[empty] = tiles[i];
    next[i] = 0;
    setTiles(next);
  }

  const FACES = ["⛄", "❄️", "🎿", "🧣", "🧤", "🛷", "🌟", "🎅"];

  return (
    <div className="flex flex-col items-center">
      <p className="mb-2 text-sm text-blue-50/80">Slide the tiles into order (1–8).</p>
      <div className="grid grid-cols-3 gap-2">
        {tiles.map((t, i) => (
          <button
            key={i}
            onClick={() => slide(i)}
            className={`flex h-20 w-20 flex-col items-center justify-center rounded-2xl text-2xl font-bold ${
              t === 0 ? "bg-transparent" : "bg-gradient-to-b from-sky-300 to-sky-500 text-white shadow-lg"
            }`}
          >
            {t !== 0 && (
              <>
                <span>{FACES[t - 1]}</span>
                <span className="text-xs">{t}</span>
              </>
            )}
          </button>
        ))}
      </div>
      {won && <p className="mt-3 font-display text-xl text-amber-200">⛄ Puzzle Pro badge earned!</p>}
    </div>
  );
}

/* ---------------- Shell ---------------- */
export default function Games({ childName, elfEmoji, earned }: Props) {
  const [open, setOpen] = useState<string | null>(null);
  const [badges, setBadges] = useState<string[]>(earned);
  const [toast, setToast] = useState<string | null>(null);

  const award = useCallback(
    async (gameKey: string, score: number) => {
      const res = await fetch("/api/games", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ gameKey, score }),
      });
      if (!res.ok) return;
      const data = (await res.json()) as { badge: string; isNew: boolean };
      if (!badges.includes(data.badge)) setBadges((b) => [...b, data.badge]);
      if (data.isNew) {
        setToast(`🏆 New badge: ${data.badge}!`);
        setTimeout(() => setToast(null), 3500);
      }
    },
    [badges],
  );

  const makeWinner = (key: string) => (score: number) => void award(key, score);

  return (
    <div>
      {toast && (
        <div className="mb-4 rounded-2xl border border-amber-300/50 bg-amber-300/20 px-4 py-3 text-center font-bold text-amber-100">
          {toast}
        </div>
      )}
      <div className="mb-4 flex flex-wrap gap-2">
        <span className="text-sm text-blue-50/80">Badges earned:</span>
        {badges.length === 0 && <span className="text-sm text-blue-50/50">none yet — go play!</span>}
        {badges.map((b) => (
          <span key={b} className="rounded-full bg-amber-400 px-3 py-1 text-xs font-bold text-red-900">
            🏅 {b}
          </span>
        ))}
      </div>

      {!open && (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {GAME_CATALOG.map((g) => (
            <button
              key={g.key}
              onClick={() => setOpen(g.key)}
              className="glass rounded-3xl p-5 text-left transition hover:-translate-y-1"
            >
              <div className="text-3xl">{g.emoji}</div>
              <h4 className="mt-2 font-display text-lg font-bold text-amber-200">{g.title}</h4>
              <p className="text-xs text-blue-50/80">{g.blurb}</p>
              {badges.includes(g.badge) && <p className="mt-2 text-xs font-bold text-emerald-300">🏅 {g.badge}</p>}
            </button>
          ))}
        </div>
      )}

      {open && (
        <div className="glass rounded-3xl p-5">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="font-display text-2xl font-bold text-amber-200">
              {GAME_CATALOG.find((g) => g.key === open)?.title}
            </h3>
            <button onClick={() => setOpen(null)} className="rounded-full bg-white/15 px-4 py-2 text-sm text-white">
              ← All games
            </button>
          </div>
          <p className="mb-4 text-sm text-blue-50/70">Good luck, {childName}!</p>
          {open === "memory" && <MemoryGame onWin={makeWinner("memory")} />}
          {open === "match-presents" && <MatchPresents onWin={makeWinner("match-presents")} />}
          {open === "find-elf" && <FindElf elfEmoji={elfEmoji} onWin={makeWinner("find-elf")} />}
          {open === "trivia" && <Trivia onWin={makeWinner("trivia")} />}
          {open === "wordsearch" && <WordSearch onWin={makeWinner("wordsearch")} />}
          {open === "maze" && <Maze onWin={makeWinner("maze")} />}
          {open === "coloring" && <Coloring onWin={makeWinner("coloring")} />}
          {open === "snowball" && <SnowballPuzzle onWin={makeWinner("snowball")} />}
        </div>
      )}
    </div>
  );
}
