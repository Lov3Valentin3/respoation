const COLORS = ["#ff5252", "#ffd54f", "#69f0ae", "#40c4ff", "#ff80ab", "#fff59d"];

export default function Lights({ bulbs = 28 }: { bulbs?: number }) {
  return (
    <div className="lights w-full" aria-hidden="true">
      {Array.from({ length: bulbs }).map((_, i) => (
        <span
          key={i}
          className="light-bulb"
          style={{
            color: COLORS[i % COLORS.length],
            animationDelay: `${(i % 6) * 0.22}s`,
          }}
        />
      ))}
    </div>
  );
}
