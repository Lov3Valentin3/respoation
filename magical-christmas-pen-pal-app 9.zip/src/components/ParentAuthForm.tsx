"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import Lights from "@/components/Lights";

export default function ParentAuthForm({ mode }: { mode: "register" | "login" }) {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");
    const res = await fetch("/api/parent/auth", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode, ...form }),
    });
    const data = await res.json();
    setLoading(false);
    if (!res.ok) return setError(data.error ?? "Something went wrong.");
    router.push("/parent/dashboard");
    router.refresh();
  }

  return (
    <main className="min-h-screen">
      <Lights bulbs={36} />
      <div className="mx-auto max-w-md px-4 py-12">
        <Link href="/" className="text-sm text-amber-200 hover:underline">← Back home</Link>
        <form onSubmit={submit} className="glass mt-4 rounded-3xl p-8">
          <div className="text-center text-4xl">{mode === "register" ? "🎄" : "🔐"}</div>
          <h1 className="mt-2 text-center font-display text-3xl font-bold text-white">
            {mode === "register" ? "Create your family account" : "Parent login"}
          </h1>
          <p className="mt-2 text-center text-sm text-blue-50/80">
            {mode === "register"
              ? "See every letter, manage children, choose how your elf replies."
              : "Welcome back to the North Pole control room."}
          </p>

          {mode === "register" && (
            <>
              <label className="mt-6 block text-sm font-semibold text-amber-200">Your name</label>
              <input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="mt-1 w-full rounded-xl border border-white/20 bg-white/90 px-4 py-3 text-slate-900 outline-none focus:ring-4 focus:ring-amber-300/40"
                required
              />
            </>
          )}

          <label className="mt-4 block text-sm font-semibold text-amber-200">Email</label>
          <input
            type="email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            className="mt-1 w-full rounded-xl border border-white/20 bg-white/90 px-4 py-3 text-slate-900 outline-none focus:ring-4 focus:ring-amber-300/40"
            required
          />

          <label className="mt-4 block text-sm font-semibold text-amber-200">Password</label>
          <input
            type="password"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
            className="mt-1 w-full rounded-xl border border-white/20 bg-white/90 px-4 py-3 text-slate-900 outline-none focus:ring-4 focus:ring-amber-300/40"
            required
            minLength={6}
          />

          {error && <p className="mt-4 rounded-xl bg-red-500/20 px-4 py-2 text-sm text-red-100">{error}</p>}

          <button
            disabled={loading}
            className="mt-6 w-full rounded-2xl bg-gradient-to-b from-red-500 to-red-700 px-6 py-4 text-lg font-bold text-white shadow-xl ring-2 ring-white/25 disabled:opacity-50"
          >
            {loading ? "One moment..." : mode === "register" ? "Create account" : "Sign in"}
          </button>

          <p className="mt-4 text-center text-sm text-blue-50/80">
            {mode === "register" ? (
              <>Already have an account? <Link href="/parent/login" className="font-bold text-amber-200 underline">Sign in</Link></>
            ) : (
              <>New here? <Link href="/parent/register" className="font-bold text-amber-200 underline">Create an account</Link></>
            )}
          </p>
        </form>
      </div>
    </main>
  );
}
