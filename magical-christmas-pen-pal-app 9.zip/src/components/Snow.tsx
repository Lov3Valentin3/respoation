"use client";

import { useEffect, useState } from "react";

type Flake = {
  left: number;
  size: number;
  duration: number;
  delay: number;
  drift: number;
  char: string;
};

const CHARS = ["❄", "❅", "❆", "•", "✦"];

export default function Snow({ count = 45 }: { count?: number }) {
  const [flakes, setFlakes] = useState<Flake[]>([]);

  useEffect(() => {
    const next: Flake[] = Array.from({ length: count }, (_, i) => ({
      left: Math.random() * 100,
      size: 8 + Math.random() * 18,
      duration: 9 + Math.random() * 14,
      delay: -Math.random() * 20,
      drift: (Math.random() - 0.5) * 160,
      char: CHARS[i % CHARS.length],
    }));
    setFlakes(next);
  }, [count]);

  return (
    <div className="snow-layer" aria-hidden="true">
      {flakes.map((f, i) => (
        <span
          key={i}
          className="snowflake"
          style={{
            left: `${f.left}%`,
            fontSize: `${f.size}px`,
            animationDuration: `${f.duration}s`,
            animationDelay: `${f.delay}s`,
            ["--drift" as string]: `${f.drift}px`,
          }}
        >
          {f.char}
        </span>
      ))}
    </div>
  );
}
