import {
  pgTable,
  serial,
  text,
  integer,
  timestamp,
  boolean,
  jsonb,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const parents = pgTable(
  "parents",
  {
    id: serial("id").primaryKey(),
    email: text("email").notNull(),
    name: text("name").notNull(),
    passwordHash: text("password_hash").notNull(),
    plan: text("plan").notNull().default("free"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("parents_email_idx").on(table.email)],
);

export const elves = pgTable(
  "elves",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull(),
    name: text("name").notNull(),
    gender: text("gender").notNull(),
    emoji: text("emoji").notNull(),
    tagline: text("tagline").notNull(),
    bio: text("bio").notNull(),
    personality: text("personality").notNull(),
    hobbies: text("hobbies").notNull(),
    job: text("job").notNull(),
    treats: text("treats").notNull(),
    funFact: text("fun_fact").notNull(),
    catchphrase: text("catchphrase").notNull(),
    theme: text("theme").notNull().default("red"),
  },
  (table) => [uniqueIndex("elves_slug_idx").on(table.slug)],
);

export const children = pgTable(
  "children",
  {
    id: serial("id").primaryKey(),
    parentId: integer("parent_id").references(() => parents.id),
    firstName: text("first_name").notNull(),
    age: integer("age").notNull(),
    favoriteColor: text("favorite_color").notNull(),
    favoriteActivity: text("favorite_activity").notNull(),
    christmasWish: text("christmas_wish"),
    birthday: text("birthday"),
    elfId: integer("elf_id").references(() => elves.id),
    magicCode: text("magic_code").notNull(),
    responseMode: text("response_mode").notNull().default("ai"),
    paused: boolean("paused").notNull().default(false),
    lettersSent: integer("letters_sent").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [uniqueIndex("children_magic_code_idx").on(table.magicCode)],
);

export const letters = pgTable("letters", {
  id: serial("id").primaryKey(),
  childId: integer("child_id").notNull().references(() => children.id),
  elfId: integer("elf_id").references(() => elves.id),
  sender: text("sender").notNull(), // 'child' | 'elf'
  body: text("body").notNull(),
  status: text("status").notNull().default("delivered"), // delivered | pending
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const memories = pgTable("memories", {
  id: serial("id").primaryKey(),
  childId: integer("child_id").notNull().references(() => children.id),
  kind: text("kind").notNull(), // fact | joke | wish | date
  value: text("value").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const certificates = pgTable("certificates", {
  id: serial("id").primaryKey(),
  childId: integer("child_id").notNull().references(() => children.id),
  key: text("key").notNull(),
  title: text("title").notNull(),
  premium: boolean("premium").notNull().default(false),
  unlockedAt: timestamp("unlocked_at", { withTimezone: true }).defaultNow().notNull(),
});

export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  childId: integer("child_id").references(() => children.id),
  elfId: integer("elf_id").references(() => elves.id),
  key: text("key").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  scene: text("scene").notNull(),
  premium: boolean("premium").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  childId: integer("child_id").notNull().references(() => children.id),
  gameKey: text("game_key").notNull(),
  badge: text("badge").notNull(),
  score: integer("score").notNull().default(0),
  earnedAt: timestamp("earned_at", { withTimezone: true }).defaultNow().notNull(),
});

export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  parentId: integer("parent_id").notNull().references(() => parents.id),
  plan: text("plan").notNull(),
  status: text("status").notNull().default("active"),
  addons: jsonb("addons").$type<string[]>().notNull().default([]),
  priceCents: integer("price_cents").notNull().default(0),
  startedAt: timestamp("started_at", { withTimezone: true }).defaultNow().notNull(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  parentId: integer("parent_id").notNull().references(() => parents.id),
  childId: integer("child_id").references(() => children.id),
  type: text("type").notNull(),
  title: text("title").notNull(),
  body: text("body").notNull(),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(),
  role: text("role").notNull(), // parent | child
  parentId: integer("parent_id").references(() => parents.id),
  childId: integer("child_id").references(() => children.id),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});

export type Parent = typeof parents.$inferSelect;
export type Child = typeof children.$inferSelect;
export type Elf = typeof elves.$inferSelect;
export type Letter = typeof letters.$inferSelect;
export type CertificateRow = typeof certificates.$inferSelect;
export type VideoRow = typeof videos.$inferSelect;
export type AchievementRow = typeof achievements.$inferSelect;
export type NotificationRow = typeof notifications.$inferSelect;
export type SubscriptionRow = typeof subscriptions.$inferSelect;
