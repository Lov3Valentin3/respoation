import { cookies } from "next/headers";
import { randomBytes, scryptSync, timingSafeEqual, randomUUID } from "crypto";
import { db } from "@/db";
import { sessions, parents, children, elves } from "@/db/schema";
import { eq } from "drizzle-orm";

const COOKIE = "northpole_session";
const THIRTY_DAYS = 1000 * 60 * 60 * 24 * 30;

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const candidate = scryptSync(password, salt, 64);
  const original = Buffer.from(hash, "hex");
  if (candidate.length !== original.length) return false;
  return timingSafeEqual(candidate, original);
}

export function makeMagicCode(name: string): string {
  const words = ["SNOW", "STAR", "BELL", "COCOA", "SLED", "HOLLY", "JOLLY", "FROST"];
  const word = words[Math.floor(Math.random() * words.length)];
  const digits = Math.floor(100 + Math.random() * 900);
  return `${name.replace(/[^a-zA-Z]/g, "").toUpperCase().slice(0, 6) || "ELF"}-${word}${digits}`;
}

export async function createSession(input: { role: "parent" | "child"; parentId?: number; childId?: number }) {
  const id = randomUUID();
  const expiresAt = new Date(Date.now() + THIRTY_DAYS);
  await db.insert(sessions).values({
    id,
    role: input.role,
    parentId: input.parentId ?? null,
    childId: input.childId ?? null,
    expiresAt,
  });
  const store = await cookies();
  store.set(COOKIE, id, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    expires: expiresAt,
    secure: process.env.NODE_ENV === "production",
  });
  return id;
}

export async function destroySession() {
  const store = await cookies();
  const id = store.get(COOKIE)?.value;
  if (id) {
    await db.delete(sessions).where(eq(sessions.id, id));
    store.delete(COOKIE);
  }
}

export async function getSession() {
  const store = await cookies();
  const id = store.get(COOKIE)?.value;
  if (!id) return null;
  const rows = await db.select().from(sessions).where(eq(sessions.id, id)).limit(1);
  const session = rows[0];
  if (!session) return null;
  if (session.expiresAt.getTime() < Date.now()) return null;
  return session;
}

export async function getCurrentParent() {
  const session = await getSession();
  if (!session || session.role !== "parent" || !session.parentId) return null;
  const rows = await db.select().from(parents).where(eq(parents.id, session.parentId)).limit(1);
  return rows[0] ?? null;
}

export async function getCurrentChild() {
  const session = await getSession();
  if (!session || session.role !== "child" || !session.childId) return null;
  const rows = await db.select().from(children).where(eq(children.id, session.childId)).limit(1);
  const child = rows[0];
  if (!child) return null;
  let elf = null;
  if (child.elfId) {
    const elfRows = await db.select().from(elves).where(eq(elves.id, child.elfId)).limit(1);
    elf = elfRows[0] ?? null;
  }
  return { child, elf };
}
