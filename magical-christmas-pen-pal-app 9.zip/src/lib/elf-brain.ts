import type { Child, Elf } from "@/db/schema";

export type MemoryFact = { kind: string; value: string };

function clean(s: string) {
  return s.replace(/\s+/g, " ").trim();
}

/** Pull long-term memory facts out of a child's letter. */
export function extractMemories(text: string): MemoryFact[] {
  const found: MemoryFact[] = [];
  const lower = text.toLowerCase();

  const patterns: { re: RegExp; kind: string; label: (m: RegExpMatchArray) => string }[] = [
    { re: /my favou?rite ([a-z ]{2,20}) is ([^.!?\n]{2,60})/gi, kind: "fact", label: (m) => `favourite ${clean(m[1])}: ${clean(m[2])}` },
    { re: /i (?:really )?love ([^.!?\n]{2,60})/gi, kind: "fact", label: (m) => `loves ${clean(m[1])}` },
    { re: /i (?:have|got) a (?:pet )?(dog|cat|hamster|rabbit|bunny|fish|bird|guinea pig|lizard|turtle)(?: (?:named|called) ([a-z]+))?/gi, kind: "fact", label: (m) => `has a ${m[1]}${m[2] ? ` named ${m[2]}` : ""}` },
    { re: /my birthday is (?:on )?([^.!?\n]{3,40})/gi, kind: "date", label: (m) => `birthday: ${clean(m[1])}` },
    { re: /i (?:want|wish for|would like|am hoping for) ([^.!?\n]{2,70}) for christmas/gi, kind: "wish", label: (m) => `Christmas wish: ${clean(m[1])}` },
    { re: /i (?:want|wish for|would like) ([^.!?\n]{2,70})/gi, kind: "wish", label: (m) => `wants ${clean(m[1])}` },
    { re: /my (brother|sister|mom|mum|dad|grandma|grandpa|teacher|best friend)(?:'s name)? is ([a-z]+)/gi, kind: "fact", label: (m) => `${m[1]} is named ${m[2]}` },
    { re: /i(?:'m| am) (\d{1,2}) years old/gi, kind: "fact", label: (m) => `is ${m[1]} years old` },
    { re: /i play ([a-z ]{2,30})/gi, kind: "fact", label: (m) => `plays ${clean(m[1])}` },
  ];

  for (const p of patterns) {
    for (const m of lower.matchAll(p.re)) {
      const value = p.label(m);
      if (value.length > 4 && !found.some((f) => f.value === value)) {
        found.push({ kind: p.kind, value });
      }
    }
  }
  return found.slice(0, 6);
}

type Topic = { key: string; test: RegExp };
const TOPICS: Topic[] = [
  { key: "snow", test: /snow|sled|sledding|snowman|ice|skat/i },
  { key: "pet", test: /dog|cat|puppy|kitten|pet|hamster|bunny|rabbit/i },
  { key: "school", test: /school|teacher|class|homework|test|reading|math/i },
  { key: "presents", test: /present|gift|toy|wish|want|christmas list/i },
  { key: "food", test: /cookie|cocoa|candy|cake|pizza|chocolate|treat|bake/i },
  { key: "reindeer", test: /reindeer|rudolph|dasher|dancer|sleigh|fly/i },
  { key: "santa", test: /santa|nice list|naughty|north pole|workshop/i },
  { key: "sad", test: /sad|lonely|scared|worried|miss|cry|bad day|nervous/i },
  { key: "family", test: /mom|mum|dad|brother|sister|grandma|grandpa|family|baby/i },
  { key: "birthday", test: /birthday|turning|cake and candles/i },
  { key: "friends", test: /friend|playdate|park|play with/i },
  { key: "sports", test: /soccer|football|dance|ballet|swim|karate|basketball|gymnastic/i },
];

const TOPIC_LINES: Record<string, string[]> = {
  snow: [
    "You should have seen the snow here this morning — it came down so thick that Sprocket lost his hat and found it three hours later on a passing penguin!",
    "I went sledding down Sugarplum Hill before breakfast and I may have accidentally landed in a snowdrift shaped exactly like a pancake.",
    "The snow at the North Pole squeaks when you walk on it. Squeak-squeak-squeak, all the way to the workshop.",
  ],
  pet: [
    "Animals are the very best listeners, aren't they? Our reindeer Comet listens to all my secrets and never tells a soul.",
    "We have a workshop puppy here named Biscuit who steals exactly one mitten a day. Only ever one. Only ever the left.",
    "Give your furry friend a scratch behind the ears from me — tell them it's official North Pole business.",
  ],
  school: [
    "Elves go to Elf School too! Today we had Wrapping Practice and I got a B-plus because my bow looked like a sleepy octopus.",
    "Learning new things makes your brain sparkle, and sparkly brains are Santa's favourite kind.",
    "My hardest subject is Chimney Geometry. So many angles! So much soot!",
  ],
  presents: [
    "I peeked at the workshop list today and I can confirm your name is written in shiny gold ink. That's all I'm allowed to say!",
    "The toy conveyor belt has been roaring all week. We made 40,000 teddy bears before lunch.",
    "Between you and me, the wrapping paper we are using this year has actual glitter from the northern lights in it.",
  ],
  food: [
    "Holly baked gingerbread stars this morning and I ate... well, let's just say a number that Santa says I shouldn't write down.",
    "My cocoa had eleven marshmallows in it today. ELEVEN. It was the greatest moment of my week.",
    "We tried a new candy cane flavour called bubblegum-snowflake and it made my ears tingle.",
  ],
  reindeer: [
    "Flight practice was WILD today. Dasher did a loop-the-loop and Blitzen sneezed mid-air and we all got a little snow-showered.",
    "The reindeer have started their winter training. Their hooves make a sound like happy thunder.",
    "Rudolph's nose was extra bright this morning. That usually means good news is on the way.",
  ],
  santa: [
    "Santa walked past my workbench and said 'Ho ho ho!' at me, which in Santa language means 'good job'.",
    "The Nice List book is glowing brighter than last year. Something tells me that's partly because of kids like you.",
    "Santa's beard got tinsel stuck in it again. He pretended not to notice for a whole hour.",
  ],
  sad: [
    "I want you to know something important: even on grey days, you matter an awful lot. Every single elf here believes in you.",
    "When I feel wobbly inside, I wrap up warm, hold my cocoa with both hands and count five things that make me smile. Want to try it with me?",
    "Tough days happen even at the North Pole. But they always, always melt — just like frost in the morning sun.",
  ],
  family: [
    "Family is the very best kind of magic. Give them a big squeeze from an elf!",
    "Our workshop is like a giant noisy family. Somebody is always singing and somebody is always losing a hammer.",
    "Tell your family the North Pole says hello — we're waving from very, very far north.",
  ],
  birthday: [
    "A BIRTHDAY?! We have a rule up here: birthdays get an extra sprinkle of snow magic. Consider it sprinkled.",
    "I'm going to bake something ridiculous and covered in frosting in your honour.",
    "I wrote your birthday on the big workshop calendar in glitter pen. It's official now.",
  ],
  friends: [
    "Friends are the best presents that never need wrapping.",
    "Me and Pip built a snow fort yesterday and defended it against absolutely nobody for two whole hours.",
    "Being a good friend is one of the fastest ways to get onto the Nice List, just so you know.",
  ],
  sports: [
    "We have the North Pole Snowball Games every winter. I came 14th. Out of 14. But I had the best hat!",
    "Practising something over and over is the secret ingredient. That's how I learned to juggle candy canes.",
    "Keep going! Every elf here is cheering for you from way up north.",
  ],
};

const OPENERS = [
  (name: string) => `Dear ${name},`,
  (name: string) => `Hello there, ${name}!`,
  (name: string) => `${name}!! You wrote back!`,
  (name: string) => `My dear friend ${name},`,
  (name: string) => `Greetings from the snowy North, ${name}!`,
];

const FIRST_REACTIONS = [
  "Your letter arrived on the mail sleigh this morning and I did a happy little jump that knocked over my cocoa.",
  "Ivy came running through the workshop shouting my name because your letter had a sparkle on it. Yours always do.",
  "The moment your envelope landed on my workbench, the bells on my hat rang all by themselves.",
  "I read your letter twice. Then a third time, out loud, to a very patient reindeer.",
  "Your words made the frost on my window melt into the shape of a smile. That really happens up here.",
];

const QUESTIONS = [
  "What's the very best thing that happened to you this week?",
  "If you could invent one brand-new toy, what would it be?",
  "What's your favourite Christmas song? I'll teach it to the choir!",
  "Do you like your snow fluffy or crunchy? This is a serious North Pole debate.",
  "What's the funniest thing that's ever made you laugh?",
  "If you had a pet reindeer, what would you name it?",
  "What's one kind thing you did lately? I want to write it in the golden book.",
  "What would you build if you had a whole workshop to yourself?",
];

const CLOSERS = [
  "Write back soon — my mailbox gets lonely!",
  "Sending you a hug wrapped in snowflakes,",
  "Yours in tinsel and true friendship,",
  "Keep believing — it makes our lights glow brighter,",
  "Until the next letter, my friend,",
];

function pick<T>(arr: T[], seed: number): T {
  return arr[Math.abs(seed) % arr.length];
}

function hash(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return h;
}

export type BrainInput = {
  child: Pick<Child, "firstName" | "age" | "favoriteColor" | "favoriteActivity" | "christmasWish" | "birthday">;
  elf: Pick<Elf, "name" | "personality" | "hobbies" | "job" | "treats" | "funFact" | "catchphrase" | "emoji">;
  letter: string;
  memories: string[];
  letterCount: number;
};

/** Deterministic, personality-consistent, memory-aware elf letter generator. */
export function composeElfLetter(input: BrainInput): string {
  const { child, elf, letter, memories, letterCount } = input;
  const seed = hash(letter + child.firstName + letterCount);
  const firstName = child.firstName;
  const paragraphs: string[] = [];

  paragraphs.push(pick(OPENERS, seed)(firstName));
  paragraphs.push(pick(FIRST_REACTIONS, seed + 7));

  // Topic-aware responses
  const topics = TOPICS.filter((t) => t.test.test(letter)).slice(0, 3);
  if (topics.length === 0) {
    paragraphs.push(
      `You'll never guess what I got up to today. My job is ${elf.job.toLowerCase()}, so of course things got a little bit chaotic and a lot bit magical. ${elf.funFact}`,
    );
  } else {
    topics.forEach((t, i) => {
      const lines = TOPIC_LINES[t.key];
      paragraphs.push(pick(lines, seed + i * 13));
    });
  }

  // Question handling
  if (letter.includes("?")) {
    const q = letter.match(/[^.!?\n]*\?/)?.[0]?.trim();
    if (q && q.length < 160) {
      paragraphs.push(
        `You asked me "${clean(q)}" — what a brilliant question. The honest North Pole answer is: yes, and it involves a lot more glitter than you'd think. I'll tell you the whole story next letter, I promise.`,
      );
    }
  }

  // Memory callbacks
  if (memories.length > 0) {
    const m = pick(memories, seed + 3);
    paragraphs.push(`I still remember you told me ${m}. I think about that a lot while I'm working — it makes me smile every time.`);
  }

  // Personal detail weaving
  const personalBits = [
    `I painted a tiny wooden ornament ${child.favoriteColor.toLowerCase()} today because that's your colour, and now everyone in the workshop wants one.`,
    `I told the other elves that you love ${child.favoriteActivity.toLowerCase()} and honestly, they were VERY impressed.`,
    `Being ${child.age} is a wonderful age for magic. That's officially the age when you can hear sleigh bells best.`,
  ];
  paragraphs.push(pick(personalBits, seed + 5));

  if (child.christmasWish) {
    paragraphs.push(`And don't worry — your Christmas wish (${child.christmasWish}) is safe with me. I whispered it to the right reindeer.`);
  }

  paragraphs.push(pick(QUESTIONS, seed + 11));
  paragraphs.push(`${pick(CLOSERS, seed + 2)}\n${elf.name} ${elf.emoji}\nP.S. ${elf.catchphrase}`);

  return paragraphs.join("\n\n");
}

/** Optional upgrade path: use a real LLM if a key is configured, otherwise fall back. */
export async function generateElfReply(input: BrainInput): Promise<string> {
  const openai = process.env.OPENAI_API_KEY;
  const anthropic = process.env.ANTHROPIC_API_KEY;
  const system = `You are ${input.elf.name}, an elf at the North Pole writing a handwritten letter to a child named ${input.child.firstName}, age ${input.child.age}.
Personality: ${input.elf.personality}. Job: ${input.elf.job}. Hobbies: ${input.elf.hobbies}. Favourite treats: ${input.elf.treats}. Catchphrase: ${input.elf.catchphrase}.
Things you remember about ${input.child.firstName}: ${input.memories.join("; ") || "this is one of your first letters"}.
Favourite colour: ${input.child.favoriteColor}. Favourite Christmas activity: ${input.child.favoriteActivity}.
Write a warm, funny, imaginative, age-appropriate letter of 150-250 words. Never break character, never mention being an AI, never ask for personal or private information, never discuss anything unsafe. End with a question and sign your name.`;

  try {
    if (openai) {
      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${openai}` },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            { role: "system", content: system },
            { role: "user", content: input.letter },
          ],
          max_tokens: 600,
        }),
      });
      if (res.ok) {
        const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
        const text = data.choices?.[0]?.message?.content;
        if (text) return text.trim();
      }
    } else if (anthropic) {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": anthropic,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: "claude-3-5-haiku-latest",
          max_tokens: 700,
          system,
          messages: [{ role: "user", content: input.letter }],
        }),
      });
      if (res.ok) {
        const data = (await res.json()) as { content?: { text?: string }[] };
        const text = data.content?.[0]?.text;
        if (text) return text.trim();
      }
    }
  } catch {
    // fall through to local generator
  }
  return composeElfLetter(input);
}
