import { db } from "@/db";
import { certificates, videos, notifications, children } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import { CERTIFICATE_CATALOG, VIDEO_CATALOG } from "./elf-data";

export async function syncUnlocks(childId: number, lettersSent: number) {
  const kid = (await db.select().from(children).where(eq(children.id, childId)).limit(1))[0];
  if (!kid) return { newCertificates: [] as string[], newVideos: [] as string[] };

  const existingCerts = await db.select().from(certificates).where(eq(certificates.childId, childId));
  const owned = new Set(existingCerts.map((c) => c.key));
  const newCertificates: string[] = [];

  for (const cert of CERTIFICATE_CATALOG) {
    if (!cert.premium && lettersSent >= cert.requirement && !owned.has(cert.key)) {
      await db.insert(certificates).values({
        childId,
        key: cert.key,
        title: cert.title,
        premium: cert.premium,
      });
      newCertificates.push(cert.title);
      if (kid.parentId) {
        await db.insert(notifications).values({
          parentId: kid.parentId,
          childId,
          type: "certificate",
          title: "New certificate unlocked! 🏅",
          body: `${kid.firstName} just unlocked "${cert.title}". It's ready to print.`,
        });
      }
    }
  }

  const existingVideos = await db.select().from(videos).where(eq(videos.childId, childId));
  const ownedVideos = new Set(existingVideos.map((v) => v.key));
  const newVideos: string[] = [];
  const unlockCount = Math.min(VIDEO_CATALOG.length, 1 + Math.floor(lettersSent / 2));

  for (const v of VIDEO_CATALOG.slice(0, unlockCount)) {
    if (!ownedVideos.has(v.key)) {
      await db.insert(videos).values({
        childId,
        elfId: kid.elfId,
        key: v.key,
        title: v.title,
        description: v.description,
        scene: v.scene,
        premium: v.premium,
      });
      newVideos.push(v.title);
      if (kid.parentId) {
        await db.insert(notifications).values({
          parentId: kid.parentId,
          childId,
          type: "video",
          title: "A new elf video arrived 🎬",
          body: `"${v.title}" is now playing in ${kid.firstName}'s video window.`,
        });
      }
    }
  }

  return { newCertificates, newVideos };
}

export async function hasCertificate(childId: number, key: string) {
  const rows = await db
    .select()
    .from(certificates)
    .where(and(eq(certificates.childId, childId), eq(certificates.key, key)))
    .limit(1);
  return Boolean(rows[0]);
}
