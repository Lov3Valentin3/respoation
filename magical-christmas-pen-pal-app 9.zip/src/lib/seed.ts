import { db } from "@/db";
import { elves } from "@/db/schema";
import { ELF_SEEDS } from "./elf-data";
import { sql } from "drizzle-orm";

let seeded = false;

export async function ensureElvesSeeded() {
  if (seeded) return;
  try {
    const rows = await db.select({ count: sql<number>`count(*)::int` }).from(elves);
    const count = rows[0]?.count ?? 0;
    if (count < ELF_SEEDS.length) {
      for (const e of ELF_SEEDS) {
        await db
          .insert(elves)
          .values(e)
          .onConflictDoNothing({ target: elves.slug });
      }
    }
    seeded = true;
  } catch {
    // table may not exist yet during first build
  }
}

export async function getAllElves() {
  await ensureElvesSeeded();
  return db.select().from(elves).orderBy(elves.id);
}
